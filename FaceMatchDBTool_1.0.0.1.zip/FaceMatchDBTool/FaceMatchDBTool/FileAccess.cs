﻿using System;
using System.Collections.Generic;
using System.IO;                    // IO 
using System.Data;                  // DataTable
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Forms;

namespace FaceMatchDBTool
{
    class FileAccess
    {
        private static FileAccess instance;

        public static FileAccess Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new FileAccess();
                }
                return instance;
            }
        }

        //ディレクトリのコピー
        public void DirectoryCopy(string sourcePath, string destinationPath)
        {
            DirectoryInfo sourceDirectory = new DirectoryInfo(sourcePath);
            DirectoryInfo destinationDirectory = new DirectoryInfo(destinationPath);

            //コピー先のディレクトリがなければ作成する
            if (destinationDirectory.Exists == false)
            {
                destinationDirectory.Create();
                destinationDirectory.Attributes = sourceDirectory.Attributes;
            }

            //ファイルのコピー
            foreach (FileInfo fileInfo in sourceDirectory.GetFiles())
            {
                //同じファイルが存在していたら、常に上書きする
                fileInfo.CopyTo(destinationDirectory.FullName + @"\" + fileInfo.Name, true);
            }

            //ディレクトリのコピー（再帰を使用）
            foreach (System.IO.DirectoryInfo directoryInfo in sourceDirectory.GetDirectories())
            {
                DirectoryCopy(directoryInfo.FullName, destinationDirectory.FullName + @"\" + directoryInfo.Name);
            }
        }

        //ディレクトリの削除
        public bool DirectoryDelete(string deletePath)
        {
            bool ret = true;
            // face ディレクトリ以下のファイルのみを削除
            DirectoryInfo deleteDirectory = new DirectoryInfo(deletePath);

            if (deleteDirectory.Exists == true)
            {
                // ディレクトリの丸ごと削除
                try
                {
                    deleteDirectory.Delete(true);
                }
                catch (Exception ex)
                {
                    ret = false;
                    //メッセージボックスを表示する
                    System.Windows.Forms.MessageBox.Show(ex.Message, "Ddetete failed[" + deletePath + "]", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            return ret;
        }

        //ディレクトリの作成
        public bool DirectoryMake(string makePath)
        {
            bool ret = true;

            DirectoryInfo makeDirectory = new DirectoryInfo(makePath);
            try
            {
                makeDirectory.Create();
                //destinationDirectory.Attributes = sourceDirectory.Attributes;
                return ret;
            }
            catch (Exception ex)
            {
                ret = false;
                //メッセージボックスを表示する
                System.Windows.Forms.MessageBox.Show(ex.Message, "Dmake failed[" + makePath + "]", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return ret;
            }
        }

        public String fileNameConvert(Int64 camNo, String passName)
        {
            String fileName;
            String camName;

            fileName = Path.GetFileName(passName);
            camName = String.Format("{0:D3}", camNo);
            fileName = camName + "_" + Path.GetFileName(passName);

            return fileName;
        }

        public void fileCopy(Int64 camNo, String passName, String dstDirName)
        {
            FileInfo fi;
            String newfileName;
            String dstfileName;

            // ファイルがないと処理がとまってしまうのでチェックを入れる。
            if (System.IO.File.Exists(passName) == false)
            {   // ファイルがなかったらコピー処理をやめる
                return;
            }

            // FileInfoオブジェクトの生成
            fi = new System.IO.FileInfo(passName);

            // ファイル名変換
            newfileName = fileNameConvert(camNo, passName);     // カメラ番号を付与したファイル名を作成
            dstfileName = dstDirName + "/" + newfileName;       // 格納先ファイル名の作成

            try
            {
                // ファイルコピー
                FileInfo copyFile = fi.CopyTo(dstfileName);         // ファイルのコピー
            }
            catch(Exception ex)
            {
                //メッセージボックスを表示する
                System.Windows.Forms.MessageBox.Show(ex.Message, "file copy failed[" + dstfileName + "]", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        

    }
}
