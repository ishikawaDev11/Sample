﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Forms;

namespace FaceMatchDBTool
{
    /// <summary>
    /// ImageDate.xaml の相互作用ロジック
    /// </summary>
    public partial class ImageDate : Window
    {
        // プロパティ
        private static int _selStatus;
        public static int selStatus
        {
            get
            {
                return _selStatus;
            }
        }

        private static string _strSelDate;
        public static string strSelDate
        {
            get
            {
                return _strSelDate;
            }
        }

        //private static string _strSelFromDate;
        //public static string strSelFromDate
        //{
        //    get
        //    {
        //        return _strSelFromDate;
        //    }
        //}

        //private static string _strSelToDate;
        //public static string strSelToDate
        //{
        //    get
        //    {
        //        return _strSelToDate;
        //    }
        //}

        public ImageDate()
        {
            InitializeComponent();

            _selStatus = -1;
            _strSelDate = String.Empty;
        }

        private void btnDateOK_Click(object sender, RoutedEventArgs e)
        {
            int retsts = 0;
            string selDT = String.Empty;

            // 時間指定の獲得
            retsts = CheckSelDateData(ref selDT);
            if (retsts == -1)
            {
                return;
            }
            _selStatus = retsts;
            _strSelDate = selDT;

            // ウインドウのクローズ
            this.Close();           
        }

        private bool CheckSelDateRange(string strDate)
        {
            bool retsts = false;

            if (System.Text.RegularExpressions.Regex.IsMatch(strDate, @"^\d{4}/\d{2}/\d{2}$",
                                                            System.Text.RegularExpressions.RegexOptions.ECMAScript))
            {
                try
                {
                    DateTime dt = DateTime.Parse(strDate + " 00:00:00");
                    retsts = true;
                }
                catch
                {
                    return retsts;
                }
            }
            return retsts;
        }

        private int CheckSelDateData(ref string selDT)
        {
            int whereFlag = 0;
            string strDate;

            if(TxtImgDate.Text.Length > 0)
            {
                strDate = TxtImgDate.Text;
                if(CheckSelDateRange(strDate) == true)
                {
                    selDT = TxtImgDate.Text;
                    whereFlag |= 1;
                }
                else
                {
                    //メッセージボックスを表示する
                    System.Windows.Forms.MessageBox.Show("'Date' is invalid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                }
            }
            return whereFlag;
        }

    }
}
