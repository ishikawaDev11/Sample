﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace FaceMatchDBTool
{
    class FaceMappingItem : DependencyObject
    {
        private static readonly DependencyPropertyKey FaceNoPropertyKey = DependencyProperty.RegisterReadOnly("FaceNo", typeof(string), typeof(FaceMappingItem), new PropertyMetadata());
        private static readonly DependencyPropertyKey CameraIdPropertyKey = DependencyProperty.RegisterReadOnly("CameraId", typeof(string), typeof(FaceMappingItem), new PropertyMetadata());
        private static readonly DependencyPropertyKey DatePropertyKey = DependencyProperty.RegisterReadOnly("Date", typeof(string), typeof(FaceMappingItem), new PropertyMetadata());
        private static readonly DependencyPropertyKey ThumbnailPropertyKey = DependencyProperty.RegisterReadOnly("Thumbnail", typeof(ImageSource), typeof(FaceMappingItem), new PropertyMetadata(null));

        public ImageSource Thumbnail
        {
            get
            {
                return (ImageSource)base.GetValue(FaceMappingItem.ThumbnailPropertyKey.DependencyProperty);
            }
            private set
            {
                base.SetValue(FaceMappingItem.ThumbnailPropertyKey, value);
            }
        }

        public string CameraId
        {
            get
            {
                return (string)base.GetValue(FaceMappingItem.CameraIdPropertyKey.DependencyProperty);
            }
            private set
            {
                base.SetValue(FaceMappingItem.CameraIdPropertyKey, value);
            }
        }

        public string Date
        {
            get
            {
                return (string)base.GetValue(FaceMappingItem.DatePropertyKey.DependencyProperty);
            }
            private set
            {
                base.SetValue(FaceMappingItem.DatePropertyKey, value);
            }
        }

        public string FaceNo
        {
            get
            {
                return (string)base.GetValue(FaceMappingItem.FaceNoPropertyKey.DependencyProperty);
            }
            private set
            {
                base.SetValue(FaceMappingItem.FaceNoPropertyKey, value);
            }
        }


        //コンストラクタ
        public FaceMappingItem(long no, string filePath, long cameraId, string Date)
        {
            if (File.Exists(filePath))
            {
                MemoryStream data = new MemoryStream(File.ReadAllBytes(filePath)); WriteableBitmap wbmp = new WriteableBitmap(BitmapFrame.Create(data)); data.Close();
                this.Thumbnail = wbmp;
            }
            else
            {
                this.Thumbnail = new System.Windows.Media.Imaging.BitmapImage();
            }

            this.CameraId = cameraId.ToString();
            this.Date = Date;
            this.FaceNo = String.Format("{0:D6}", no);
        }
    }
}

