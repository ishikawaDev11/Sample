﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using System.IO;                    // IO 
using System.Data;
using System.Windows.Forms;
using Npgsql;

namespace FaceMatchDBTool
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {

        private readonly ObservableCollection<MappingItem> m_mapping = new ObservableCollection<MappingItem>();

        private ReadOnlyObservableCollection<MappingItem> Mapping
        {
            get;
            set;
        }

        // -------------- Tab(AlarmHistory) アラーム履歴 ---------
        DataTable rtDataTable;
        DataTable almDataTable;
        DataTable impDataTable;
        bool bLoadMap = false;
        bool bInportMap = false;

        // ---< Page View >---  // 2013.11.18 ishi11
        Int32 readPtr = 0;
        Int32 startPtr = 0;
        Int32 endPtr = 0;
        Int32 totalPtr = 0;
        const Int32 PAGE_LIMIT_DATA = 256;
        const Int32 TTL_MAX_DATA = 99999999;    // 1億


        // ---< Export用 >---
        const string EXP_FILE_PATH = @"./export";
        const string EXP_FILE_NAME = "rtinfo.csv";
        //const string EXP_INFO_FILE_PATH = @"./export/rtinfo.csv";
        const string EXP_INFO_FILE_PATH = EXP_FILE_PATH + "/" + EXP_FILE_NAME;
        const string ALM_FILE_PATH = @"./export/thumbnail";
        const string REG_FILE_PATH = @"./export/alarm";
        const string TMPRCV_FILE_PATH = @"./export/tmprcv";

        // ---< Import用 >---
        const string SJ_ALM_FILE_PATH = @"./export/thumbnail/";
        const string SJ_REG_FILE_PATH = @"./export/alarm/";

        // ---< 画像無し時用 >---
        const string UNKNOWN_FACE_PATH = @"./gender_unknown.png";

        // -------------- Tab(FaceDBDelete) 顔データ初期化 ---------
        // DataBase関連
        NpgsqlConnection connMM;
        NpgsqlConnection connOMM;
        // MM Database
        string sqlMM = "Server=127.0.0.1;Port=5432;User Id=MM_USER;Password=MM_USER_PASS;Database=MM;";
        //string delsqlMM = "DELETE FROM face_md_data_related_info";
        string delsqlMM = "TRUNCATE face_md_data_related_info";
        // OMM Database
        string sqlOMM = "Server=127.0.0.1;Port=5432;User Id=OMM_USER;Password=OMM_USER_PASS;Database=OMM;";
        //string delsqlOMM1 = "DELETE FROM tmp_receive_info";
        //string delsqlOMM2 = "DELETE FROM rt_alarm_history";
        //string delsqlOMM3 = "DELETE FROM rt_alarm_matching_info";
        string delsqlOMM1 = "TRUNCATE tmp_receive_info";
        string delsqlOMM2 = "TRUNCATE rt_alarm_history";
        string delsqlOMM3 = "TRUNCATE rt_alarm_matching_info";

        // ファイルアクセス関連
        private const string SRC_FILE_PATH = "C:/ASF900/batch/msm/00_face_init";
        private const string DST_FILE_PATH = "C:/ASF900/batch/msm";
        bool bFcopy;

        // バックグラウンド関連
        System.ComponentModel.BackgroundWorker WorkerAll;
        System.ComponentModel.BackgroundWorker WorkerMM;
        System.ComponentModel.BackgroundWorker WorkerOMM1;
        System.ComponentModel.BackgroundWorker WorkerOMM2;
        System.ComponentModel.BackgroundWorker WorkerOMM3;
        UInt16 sALLflag = STS_INIT;
        UInt16 sMMflag = STS_INIT;
        UInt16 sOMM1flag = STS_INIT;
        UInt16 sOMM2flag = STS_INIT;
        UInt16 sOMM3flag = STS_INIT;
        UInt16 sFCPflag = STS_INIT;
        private const UInt16 STS_INIT = 0;
        private const UInt16 STS_OK = 1;
        private const UInt16 STS_NG = 2;

        // Logデータ
        string proclog;

        // テスト用関連
        private const UInt16 TESTDTMAKE = 0;
        //private const UInt16 TESTDTMAKE = 1;
        private const Int32 TESTCNTMAX = 250000;
        //private const Int32 TESTCNTMAX = 10001;
        private const Int32 TESTCNTDIV = 10000;
        private const string THUMB_FILE_PATH = "C:/ASF900/img/thumbnail/";
        private const string REGIST_FILE_PATH = "C:/ASF900/img/alarm/";

        // -------------- Tab(TmpRcv) 受信サムネイルデータ ---------
        private readonly ObservableCollection<FaceMappingItem> m_face_mapping = new ObservableCollection<FaceMappingItem>();

        private ReadOnlyObservableCollection<FaceMappingItem> FaceMapping
        {
            get;
            set;
        }

        // データテーブル
        DataTable faceDataTable;

        // ---< Page View >---
        Int32 readFacePtr = 0;
        Int32 startFacePtr = 0;
        Int32 endFacePtr = 0;
        Int32 totalFacePtr = 0;
        const Int32 FACE_PAGE_LIMIT_DATA = 256;
        const Int32 FACE_TTL_MAX_DATA = 99999999;    // 1億

        // テスト用関連
        //private const UInt16 TEST_THUMB_DTMAKE = 0;
        //private const UInt16 TEST_THUMB_DTMAKE = 1;

        // -------------- Tab(imgView) 受信サムネイルデータ ---------
        private readonly ObservableCollection<ImageMappingItem> m_image_mapping = new ObservableCollection<ImageMappingItem>();

        private ReadOnlyObservableCollection<ImageMappingItem> ImageMapping
        {
            get;
            set;
        }

        // データテーブル
        DataTable imageDataTable;           // 全データ
        DataTable imageSearchDataTable;     // 表示用データ
        DataTable imageMacDataTable;        // MAC情報データ
        int selDateStatus;                  // 日付指定         // 2013.12.04 ishi11
        Int32 selectFromDate;               // 日付指定         // 2013.12.04 ishi11
        Int32 selectToDate;                 // 日付指定         // 2013.12.04 ishi11

        // ---< Page View >---
        Int32 readImagePtr = 0;
        Int32 startImagePtr = 0;
        Int32 endImagePtr = 0;
        Int32 totalImagePtr = 0;
        const Int32 IMAGE_PAGE_LIMIT_DATA = 256;
        const Int32 IMAGE_TTL_MAX_DATA = 99999999;    // 1億

        // for SearchView
        public int macAddrCount = 0;
        //public const int MAX_MACLIST_CNT = 20;
        public const int MAX_MACLIST_CNT = 256;
        //public string[] strMacaddress = new string[MAX_MACLIST_CNT]{"","","","","","","","","","",
        //                                                          "","","","","","","","","",""};
        public string[] strMacaddress = new string[MAX_MACLIST_CNT];

        // Thumbnail path/file
        //  C:\\ASF900\\img\\thumbnail\\(MAC8桁)\\(MAC2桁)\\(MAC2桁)\\(年)\\(月)\\(日)\\(時)
        //  C:\\ASF900\\img\\thumbnail\\aaaaaaaa\\bb\\cc\\2013\\11\\11\\00
        //  01 2345678 9012 3456789012 345678901 234 567 89012 345 678 9012345678901234567890
        const int IMG_MAC1_POS = 24;
        const int IMG_MAC1_LEN = 8;
        const int IMG_MAC2_POS = 33;
        const int IMG_MAC2_LEN = 2;
        const int IMG_MAC3_POS = 36;
        const int IMG_MAC3_LEN = 2;
        const int IMG_YEAR_POS = 0;
        const int IMG_YEAR_LEN = 4;
        const int IMG_MONTH_POS = 4;
        const int IMG_MONTH_LEN = 2;
        const int IMG_DATE_POS = 6;
        const int IMG_DATE_LEN = 2;
        const int IMG_HOUR_POS = 8;
        const int IMG_MIN_POS = 10;
        const int IMG_SEC_POS = 12;
        const int IMG_HOUR_LEN = 2;
        const int IMG_MIN_LEN = 2;
        const int IMG_SEC_LEN = 2;


        // 
        // -------- Main Program Start --------
        //
        public MainWindow()
        {
            this.Mapping = new ReadOnlyObservableCollection<MappingItem>(this.m_mapping);
            this.FaceMapping = new ReadOnlyObservableCollection<FaceMappingItem>(this.m_face_mapping);
            this.ImageMapping = new ReadOnlyObservableCollection<ImageMappingItem>(this.m_image_mapping);
            InitializeComponent();

            // -------------- Tab(AlarmHistory) アラーム履歴 ---------
            // DataTable構築
            // 顔照合履歴用/表示用
            rtDataTable = new DataTable();
            rtDataTable.Columns.Add("CameraNo", typeof(Int64));
            rtDataTable.Columns.Add("ShotDate", typeof(String));
            rtDataTable.Columns.Add("DetectId", typeof(Int64));
            rtDataTable.Columns.Add("RegFace", typeof(String));
            rtDataTable.Columns.Add("AlmFace", typeof(String));
            rtDataTable.Columns.Add("Score", typeof(Decimal));
            // 顔照合データ用
            almDataTable = new DataTable();
            almDataTable.Columns.Add("DetectId", typeof(Int64));
            almDataTable.Columns.Add("RegFace", typeof(String));

            // 初期データ設定
            pageViewInit();

            // Export ボタン無効
            ExportButton.IsEnabled = false;

            // Next/Previous ボタン無効
            skipButton(false);

            // 時間範囲指定の初期化
            faceAlarmDateRangeInit();

            // -------------- Tab(TmpRcv) サムネイル表示 ---------
            // DataTable構築
            // 顔照合履歴用/表示用
            faceDataTable = new DataTable();
            faceDataTable.Columns.Add("CameraId", typeof(Int64));
            faceDataTable.Columns.Add("Date", typeof(String));
            faceDataTable.Columns.Add("DetFace", typeof(String));

            // 初期データ設定
            pageFaceViewInit();

            // Export ボタン無効
            //btnExport.IsEnabled = false;

            // Next/Previous ボタン無効
            skipThumbButton(false);

            // 時間範囲指定の初期化
            faceDateRangeInit();

            // -------------- Tab(FaceDBDelete) 顔データ初期化 ---------
            // Label Clear
            // LblStatus.Content = String.Empty;
            //LblmddataOK.Content = String.Empty;
            //LbltmpRecOK.Content = String.Empty;
            //LblrtHistOK.Content = String.Empty;
            //LblrtmatchOK.Content = String.Empty;

            bFcopy = true;
            //CbFcopy.IsChecked = bFcopy;

            // Log data Clear
            //TxtLogData.Text = String.Empty;

            // -------------- Tab(ImageView) サムネイル表示 ---------
            // DataTable構築
            // 顔照合履歴用/表示用
            imageDataTable = new DataTable();
            imageDataTable.Columns.Add("MacAddress", typeof(String));
            imageDataTable.Columns.Add("ImageDate", typeof(String));
            imageDataTable.Columns.Add("ImageFace", typeof(String));
            imageSearchDataTable = new DataTable();
            imageMacDataTable = new DataTable();
            imageMacDataTable.Columns.Add("MacCount", typeof(int));
            imageMacDataTable.Columns.Add("MacStr", typeof(String));

            // 選択日の初期化  // 2013.12.04 ishi11
            selDateStatus = -1;
            selectFromDate = 0;
            selectToDate = 0;

            // 初期データ設定
            pageImageViewInit();

            // Search ボタン無効
            //btnSearchImage.IsEnabled = false;

            // Next/Previous ボタン無効
            skipImageButton(false);

        }

        //
        // -------------- Tab(AlarmHistory) アラーム履歴 ---------
        //
        // Page View ボタン制御
        private void skipButton(bool status)
        {
            NextButton.IsEnabled = status;
            PrevButton.IsEnabled = status;
        }
        private void nextButton(bool status)
        {
            NextButton.IsEnabled = status;
        }
        private void prevButton(bool status)
        {
            PrevButton.IsEnabled = status;
        }


        void pageViewInit()                                             // 2013.11.18 ishi11
        {
            readPtr = 0;
            startPtr = 0;
            endPtr = 0;
            totalPtr = 0;
            TAlarmNo.Content = "";
            AlarmNo.Text = "";
        }

        void totalAlarmAdd()
        {
            totalPtr++;
            TAlarmNo.Content = totalPtr.ToString();
        }

        private void LoadButton_Click(object sender, RoutedEventArgs e)
        {
            // Mapping初期化
            mappingClear();

            // Mappingソース識別
            bLoadMap = true;
            bInportMap = false;

            // 初期データ設定                                           // 2013.11.18 ishi11
            pageViewInit();                                             // 2013.11.18 ishi11

            if (LoadFaceData() == false)
            {
                return;
            }

            // Export ボタン有効
            ExportButton.IsEnabled = true;

            // Next/Previous ボタン有効
            skipButton(true);

            //メッセージボックスを表示する
            System.Windows.Forms.MessageBox.Show("Load Completed !!", "Load", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        void dataTableInit()
        {
            //DataTable初期化
            if (rtDataTable != null)
            {
                DataRow[] rows;
                try
                {
                    rows = rtDataTable.Select();
                    Array.ForEach<DataRow>(rows, row => rtDataTable.Rows.Remove(row));
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine("Error rt Delete " + ex.Message);
                }
                rows = null;
            }

            //DataTable初期化
            if (almDataTable != null)
            {
                DataRow[] rows;
                try
                {
                    rows = almDataTable.Select();
                    Array.ForEach<DataRow>(rows, row => almDataTable.Rows.Remove(row));
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine("Error alm Delete " + ex.Message);
                }
                rows = null;
            }
        }

#if false
        private string CheckInputAlarmData(String sql, string strTxtFrom, string strTxtTo)
        {
            Boolean whereFlag = false;

            if (strTxtFrom.Length > 0)
            {
                if (CheckDateRange(strTxtFrom) == false)
                {
                    System.Windows.Forms.MessageBox.Show("'From' is invalid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return null;
                }
                if (whereFlag)
                {
                    sql = sql + " and";
                }
                else
                {
                    sql = sql + " where";
                }
                sql = sql + " to_char(event_timestamp, 'YYYY/MM/DD HH24:MI') >= :from";
                whereFlag = true;
            }

            if (strTxtTo.Length > 0)
            {
                if (CheckDateRange(strTxtTo) == false)
                {
                    System.Windows.Forms.MessageBox.Show("'To' is invalid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return null;
                }
                if (whereFlag)
                {
                    sql = sql + " and";
                }
                else
                {
                    sql = sql + " where";
                }
                sql = sql + " to_char(event_timestamp, 'YYYY/MM/DD HH24:MI') <= :to";
                whereFlag = true;
            }

            if (whereFlag == true)
            {
                sql = sql + " order by event_timestamp desc";
            }
            return (sql);
        }
#endif

        private bool LoadFaceData()
        {
            bool status = false;

            //DataTable初期化
            dataTableInit();

            // 初期データ設定                                           // 2013.11.18 ishi11
            pageViewInit();                                             // 2013.11.18 ishi11

            //PostgreSQLに接続
            NpgsqlConnection conn = new NpgsqlConnection("Server=127.0.0.1;Port=5432;User Id=OMM_USER;Password=OMM_USER_PASS;Database=OMM;");
            try
            {
                conn.Open();
            }
            catch (Exception ex)
            {
                //メッセージボックスを表示する
                System.Windows.Forms.MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return status;
            }

            // SQLパラメータ
            String hissql = "select * from rt_alarm_history";
            //hissql = CheckInputAlarmData(hissql, ucAlarmDateRange.TxtFrom.Text, ucAlarmDateRange.TxtTo.Text);
            hissql = CheckInputData(hissql, "event_timestamp", ucAlarmDateRange.TxtFrom.Text, ucAlarmDateRange.TxtTo.Text);
            if (hissql == null)
            {   // 既にメッセージ出しているので、ここでは戻るのみ
                return status;
            }
            String almsql = "select * from rt_alarm_matching_info";

            //　コマンドを生成
            //NpgsqlCommand hiscmd = new NpgsqlCommand(hissql, conn);     // RT照合アラーム履歴のDBデータを読み込む
            NpgsqlCommand hiscmd = SetParameter(conn, hissql, ucAlarmDateRange.TxtFrom.Text, ucAlarmDateRange.TxtTo.Text);
                                                                        // RTアラーム履歴のDBデータを読み込む
            NpgsqlCommand almcmd = new NpgsqlCommand(almsql, conn);     // RT照合データのDBデータを読み込む

            try
            {
                // rt_alarm_history を読み出して Datatableに必要な情報をセットする
                NpgsqlDataReader dr = hiscmd.ExecuteReader();
                DataRow rowInfo;
                Int64 rt_alarm_matching_info_id;
                Int64 camera_id;
                String thumbnail_file_path;
                String event_timestamp;
                Decimal degree_of_similarity;

                while (dr.Read())
                {
                    rt_alarm_matching_info_id = dr.GetInt64(1);
                    camera_id = dr.GetInt64(2);
                    thumbnail_file_path = dr.GetString(4);
                    event_timestamp = DateTimeUtil.ConvUTCToLocalDateTime(dr.GetDateTime(5)).ToString();
                    degree_of_similarity = dr.GetDecimal(6);

                    rowInfo = rtDataTable.NewRow();
                    rowInfo["CameraNo"] = camera_id;                            // CameraNo
                    rowInfo["ShotDate"] = event_timestamp;                      // ShotDate
                    rowInfo["DetectId"] = rt_alarm_matching_info_id;            // DetectId
                    rowInfo["RegFace"] = Path.GetFullPath(UNKNOWN_FACE_PATH);   // RegFace      // 2013.11.29 ishi11
                    rowInfo["AlmFace"] = thumbnail_file_path;                   // AlmFace
                    rowInfo["Score"] = degree_of_similarity;                    // Score
                    rtDataTable.Rows.Add(rowInfo);
                }

                // rt_alarm_matching_info を読み出して Datatableに必要な情報をセットする
                NpgsqlDataReader almdr = almcmd.ExecuteReader();
                DataRow almrowInfo;
                Int64 rt_alarm_matching_info_id2;
                String thumbnail_file_path2;

                while (almdr.Read())
                {
                    rt_alarm_matching_info_id2 = almdr.GetInt64(0);
                    thumbnail_file_path2 = almdr.GetString(2);

                    almrowInfo = almDataTable.NewRow();
                    almrowInfo["DetectId"] = rt_alarm_matching_info_id2;     // DetectId
                    almrowInfo["RegFace"] = thumbnail_file_path2;            // RegFace
                    almDataTable.Rows.Add(almrowInfo);
                }


                // 表示用DataTableの完成
                Int64 detId;                                               // Detect Id
                Int64 detId2;                                               // Detect Id
                foreach (DataRow drow in rtDataTable.Rows)
                {
                    detId = (Int64)drow["DetectId"];
                    foreach (DataRow almdrow in almDataTable.Rows)
                    {
                        detId2 = (Int64)almdrow["DetectId"];
                        if (detId == detId2)
                        {
                            drow["RegFace"] = (String)almdrow["RegFace"];
                            break;
                        }
                    }
                }

#if true
                // アラーム件数チェック
                foreach (DataRow drow2 in rtDataTable.Rows)
                {
                    totalAlarmAdd();
                }

                if (AlarmNo.Text != "")
                {   // 番号指定
                    try
                    {
                        readPtr = Convert.ToInt32(AlarmNo.Text);
                    }
                    catch
                    {   // 再入力
                        System.Windows.Forms.MessageBox.Show("Alarm no. Illegal !!", "Import", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return status;
                    }
                }
                else
                {   // 最初から
                    readPtr++;
                }
                startPtr = readPtr;
                if (viewPointerGet(startPtr) == false)
                {
                    System.Windows.Forms.MessageBox.Show("Alarm data Nothing !!", "Import", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    mapView(rtDataTable, startPtr, endPtr);
                    status = true;
                }
                conn.Close();
#else
                // マッピングアイテムに設定する
                Int32 cnt=0;                                                            // 2013.11.18 ishi11
                m_mapping.Clear();                              // マッピング初期化
                foreach (DataRow drow2 in rtDataTable.Rows)     // マッピング設定
                {
                    cnt++;                                                              // 2013.11.18 ishi11
                    camera_id = (Int64)drow2["CameraNo"];
                    event_timestamp = (String)drow2["ShotDate"];
                    rt_alarm_matching_info_id = (Int64)drow2["DetectId"];
                    thumbnail_file_path = (String)drow2["AlmFace"];
                    thumbnail_file_path2 = (String)drow2["RegFace"];
                    degree_of_similarity = (Decimal)drow2["Score"];
                    //MappingItem item = new MappingItem(dr.GetString(0), dr.GetInt64(1), DateTimeUtil.ConvUTCToLocalDateTime(dr.GetDateTime(2)).ToString(), dr.GetString(3));
                    //MappingItem item = new MappingItem(thumbnail_file_path, camera_id, event_timestamp, rt_alarm_matching_info_id.ToString());         // 2013.11.14 ishi11
                    //MappingItem item = new MappingItem(thumbnail_file_path, camera_id, event_timestamp, rt_alarm_matching_info_id.ToString(), 
                    MappingItem item = new MappingItem(cnt,thumbnail_file_path, camera_id, event_timestamp, rt_alarm_matching_info_id.ToString(),
                                                                                                degree_of_similarity.ToString(), thumbnail_file_path2);  // 2013.11.14 ishi11
                    m_mapping.Add(item);
                }
                m_listView.ItemsSource = Mapping;
#endif
            }
            catch(Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message, "Import", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                conn.Close();
            }

            m_listView.ItemsSource = Mapping;

            return status;
        }

        private void mapView(DataTable dt, Int32 readStart, Int32 readEnd)
        {

            // マッピングアイテムに設定する
            Int64 camera_id;
            String event_timestamp;
            Int64 rt_alarm_matching_info_id;
            String thumbnail_file_path;
            String thumbnail_file_path2;
            Decimal degree_of_similarity;
            String tmp;
            String tmp1;
            String tmp2;
            String tmp_path;
            Int32 sttcnt = readStart - 1;
            Int32 endcnt = readEnd - 1;

            // ---<< Exportされたデータの表示>>---
            m_mapping.Clear();                              // マッピング初期化

            // ガベージコレクション                                     // 2013.11.19 ishi11
            GC.Collect();                                               // 2013.11.19 ishi11

            // 行数分のマッピングアイテム設定を実施
            Int32 cnt;
            DataRow draw;
            for (cnt = sttcnt; cnt < endcnt; cnt++)
            {
                draw = dt.Rows[cnt];
                camera_id = (Int64)draw["CameraNo"];
                event_timestamp = (String)draw["ShotDate"];
                rt_alarm_matching_info_id = (Int64)draw["DetectId"];
                if (bInportMap == true)
                {
                    tmp1 = SJ_ALM_FILE_PATH;
                    tmp2 = FileAccess.Instance.fileNameConvert(camera_id, (String)draw["AlmFace"]);                    // CSVデータからアラーム画像ファイル名獲得
                    tmp = tmp1 + tmp2;
                    tmp_path = System.IO.Path.GetFullPath(tmp);                                     // フルパスの画像ファイル名獲得
                    thumbnail_file_path = tmp_path;
                    tmp1 = SJ_REG_FILE_PATH;
                    tmp2 = FileAccess.Instance.fileNameConvert(rt_alarm_matching_info_id, (String)draw["RegFace"]);
                                                                                                    // CSVデータから照合画像ファイル名獲得
                    tmp = tmp1 + tmp2;
                    tmp_path = System.IO.Path.GetFullPath(tmp);                                     // フルパスの画像ファイル名獲得
                    thumbnail_file_path2 = tmp_path;
                }
                else
                {
                    thumbnail_file_path = (String)draw["AlmFace"];
                    thumbnail_file_path2 = (String)draw["RegFace"];
                }
                degree_of_similarity = (Decimal)draw["Score"];
                // マッピングアイテムの設定(１行)
                //MappingItem item = new MappingItem(thumbnail_file_path, camera_id, event_timestamp, rt_alarm_matching_info_id.ToString(),             // 2013.11.18 ishi11
                MappingItem item = new MappingItem((cnt + 1), thumbnail_file_path, camera_id, event_timestamp, rt_alarm_matching_info_id.ToString(),    // 2013.11.18 ishi11
                                                                                            degree_of_similarity.ToString(), thumbnail_file_path2);
                m_mapping.Add(item);
            }

            // マッピングアイテムの表示
            m_listView.ItemsSource = Mapping;
        }

        bool viewPointerGet(Int32 ptr)
        {
            bool ret = false;
            if (ptr > totalPtr)
            {   // Warning
            }
            else
            {
                endPtr = ptr + PAGE_LIMIT_DATA;
                if (endPtr > totalPtr)
                {
                    endPtr = totalPtr + 1;
                }
                ret = true;
            }
            return ret;
        }

        private void ImportButton_Click(object sender, RoutedEventArgs e)
        {
            // ---<< Exportされたデータがあるかをチェック >>---
            Int16 errNo = 0;
            String errTitle = "Data Nothing !!\n";
            String errCmt = "";

            // Mapping初期化
            mappingClear();

            // Mappingソース識別
            bLoadMap = false;
            bInportMap = true;

            // 初期データ設定                                           // 2013.11.18 ishi11
            pageViewInit();                                             // 2013.11.18 ishi11

            // export ディレクトリのチェック
            if (Directory.Exists(EXP_FILE_PATH) == false)
            {
                errNo++;
                errCmt = "[export/...]\n";
            }
            if (errNo == 0)     // exportディレクトリがあるときのみチェック
            {
                try
                {
                    // export/thumbnail ディレクトリのチェック
                    if (Directory.Exists(ALM_FILE_PATH) == false)
                    {
                        errNo++;
                        errCmt += "[export/thumbnail/...]\n";
                    }
                    // export/alarm ディレクトリのチェック
                    if (Directory.Exists(REG_FILE_PATH) == false)
                    {
                        errNo++;
                        errCmt += "[export/alarm/...]\n";
                    }
                    // export/rtinfo.csv ファイルのチェックする
                    if (File.Exists(EXP_INFO_FILE_PATH) == false)
                    {
                        errNo++;
                        errCmt += "[export/rtinfo.csv]\n";
                    }
                }
                catch (Exception ex)
                {
                    System.Windows.Forms.MessageBox.Show(ex.Message, "Import", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            if (errNo != 0)
            {
                errTitle += errCmt;
                System.Windows.Forms.MessageBox.Show(errTitle, "Import", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            // Export ボタン無効
            ExportButton.IsEnabled = false;

            // Next/Previous ボタン有効
            skipButton(true);

#if true    // CSVファイルがSJIS形式になっていることが条件
            // ※ネット上からのパクリなので理由は不明
            //   CSVファイルをSJISで格納していたのでそのまま使用

            // イメージデータパスの文字列
            string csvDir = EXP_FILE_PATH + "/";
            string csvFileName = EXP_FILE_NAME;
            //接続文字列
            string conString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source="
                + csvDir + ";Extended Properties=\"text;HDR=Yes;FMT=Delimited\"";

            // OLEDB(Jetプロバイダ)に接続
            try
            {
                System.Data.OleDb.OleDbConnection con =
                    new System.Data.OleDb.OleDbConnection(conString);
                string commText = "SELECT * FROM [" + csvFileName + "]";

                System.Data.OleDb.OleDbDataAdapter da =
                    new System.Data.OleDb.OleDbDataAdapter(commText, con);
                // DataTableの生成
                impDataTable = new DataTable();
                // ヘッダの生成
                impDataTable.Columns.Add("CameraNo", typeof(Int64));
                impDataTable.Columns.Add("ShotDate", typeof(String));
                impDataTable.Columns.Add("DetectId", typeof(Int64));
                impDataTable.Columns.Add("RegFace", typeof(String));
                impDataTable.Columns.Add("AlmFace", typeof(String));
                impDataTable.Columns.Add("Score", typeof(Decimal));
                // DataTableに CSVファイルのデータを格納する
                da.Fill(impDataTable);
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message, "OLEDB", MessageBoxButtons.OK, MessageBoxIcon.Warning);   // Debug 2013.11.29 ishi11
            }
#endif

            // アラーム件数チェック
            foreach (DataRow drow2 in impDataTable.Rows)
            {
                totalAlarmAdd();
            }

            if (AlarmNo.Text != "")
            {   // 番号指定
                try
                {
                    readPtr = Convert.ToInt32(AlarmNo.Text);
                    if (readPtr == 0)
                    {
                        readPtr++;
                    }
                }
                catch
                {   // 再入力
                    System.Windows.Forms.MessageBox.Show("Alarm no. Illegal !!", "Import", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }
            else
            {   // 最初から
                readPtr++;
            }
            startPtr = readPtr;
            if (viewPointerGet(startPtr) == false)
            {
                System.Windows.Forms.MessageBox.Show("Alarm data Nothing !!", "Import", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
#if true
            mapView(impDataTable, startPtr, endPtr);
#if false
            // マッピングアイテムに設定する
            Int64 camera_id;
            String event_timestamp;
            Int64 rt_alarm_matching_info_id;
            String thumbnail_file_path;
            String thumbnail_file_path2;
            Decimal degree_of_similarity;
            String tmp;
            String tmp1;
            String tmp2;
            String tmp_path;

            // ---<< Exportされたデータの表示>>---
            m_mapping.Clear();                              // マッピング初期化

            // 行数分のマッピングアイテム設定を実施
            Int32 cnt;
            DataRow draw;
            for (cnt = startPtr; cnt < endPtr;cnt++ )
            {
                draw = dt.Rows[cnt];
                camera_id = (Int64)draw["CameraNo"];
                event_timestamp = (String)draw["ShotDate"];
                rt_alarm_matching_info_id = (Int64)draw["DetectId"];
                tmp1 = SJ_ALM_FILE_PATH;
                tmp2 = fileNameConvert(camera_id, (String)draw["AlmFace"]);                    // CSVデータからアラーム画像ファイル名獲得
                tmp = tmp1 + tmp2;
                tmp_path = System.IO.Path.GetFullPath(tmp);                                     // フルパスの画像ファイル名獲得
                thumbnail_file_path = tmp_path;
                tmp1 = SJ_REG_FILE_PATH;
                tmp2 = fileNameConvert(rt_alarm_matching_info_id, (String)draw["RegFace"]);    // CSVデータから照合画像ファイル名獲得
                tmp = tmp1 + tmp2;
                tmp_path = System.IO.Path.GetFullPath(tmp);                                     // フルパスの画像ファイル名獲得
                thumbnail_file_path2 = tmp_path;
                degree_of_similarity = (Decimal)draw["Score"];
                // マッピングアイテムの設定(１行)
                //MappingItem item = new MappingItem(thumbnail_file_path, camera_id, event_timestamp, rt_alarm_matching_info_id.ToString(),             // 2013.11.18 ishi11
                MappingItem item = new MappingItem((cnt+1),thumbnail_file_path, camera_id, event_timestamp, rt_alarm_matching_info_id.ToString(),       // 2013.11.18 ishi11
                                                                                            degree_of_similarity.ToString(), thumbnail_file_path2);
                m_mapping.Add(item);
            }

            // マッピングアイテムの表示
            m_listView.ItemsSource = Mapping;
#endif
#else
            // マッピングアイテムに設定する
            Int64 camera_id;
            String event_timestamp;
            Int64 rt_alarm_matching_info_id;
            String thumbnail_file_path;
            String thumbnail_file_path2;
            Decimal degree_of_similarity;
            String tmp;
            String tmp1;
            String tmp2;
            String tmp_path;

            // ---<< Exportされたデータの表示>>---
            m_mapping.Clear();                              // マッピング初期化

            // 行数分のマッピングアイテム設定を実施
            foreach (DataRow drow2 in dt.Rows)
            {
                camera_id = (Int64)drow2["CameraNo"];
                event_timestamp = (String)drow2["ShotDate"];
                rt_alarm_matching_info_id = (Int64)drow2["DetectId"];
                tmp1 = SJ_ALM_FILE_PATH;
                tmp2 = fileNameConvert(camera_id, (String)drow2["AlmFace"]);                    // CSVデータからアラーム画像ファイル名獲得
                tmp = tmp1 + tmp2;
                tmp_path = System.IO.Path.GetFullPath(tmp);                                     // フルパスの画像ファイル名獲得
                thumbnail_file_path = tmp_path;
                tmp1 = SJ_REG_FILE_PATH;
                tmp2 = fileNameConvert(rt_alarm_matching_info_id, (String)drow2["RegFace"]);    // CSVデータから照合画像ファイル名獲得
                tmp = tmp1 + tmp2;
                tmp_path = System.IO.Path.GetFullPath(tmp);                                     // フルパスの画像ファイル名獲得
                thumbnail_file_path2 = tmp_path;
                degree_of_similarity = (Decimal)drow2["Score"];
                // マッピングアイテムの設定(１行)
                MappingItem item = new MappingItem(thumbnail_file_path, camera_id, event_timestamp, rt_alarm_matching_info_id.ToString(),
                                                                                            degree_of_similarity.ToString(), thumbnail_file_path2);
                m_mapping.Add(item);
            }

            // マッピングアイテムの表示
            m_listView.ItemsSource = Mapping;
#endif
            //メッセージボックスを表示する
            System.Windows.Forms.MessageBox.Show("Import Completed !!", "Import", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

#if false   // FileAccess.csに移動
        //ディレクトリの削除
        public bool DirectoryDelete(string deletePath)
        {
            bool ret = true;
            // face ディレクトリ以下のファイルのみを削除
            DirectoryInfo deleteDirectory = new DirectoryInfo(deletePath);

            if (deleteDirectory.Exists == true)
            {
                // ディレクトリの丸ごと削除
                try
                {
                    deleteDirectory.Delete(true);
                }
                catch (Exception ex)
                {
                    ret = false;
                    //メッセージボックスを表示する
                    System.Windows.Forms.MessageBox.Show(ex.Message, "Ddetete failed[" + deletePath + "]", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            return ret;
        }

        //ディレクトリの作成
        public bool DirectoryMake(string makePath)
        {
            bool ret = true;

            DirectoryInfo makeDirectory = new DirectoryInfo(makePath);
            try
            {
                makeDirectory.Create();
                //destinationDirectory.Attributes = sourceDirectory.Attributes;
                return ret;
            }
            catch (Exception ex)
            {
                ret = false;
                //メッセージボックスを表示する
                System.Windows.Forms.MessageBox.Show(ex.Message, "Dmake failed[" + makePath + "]", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return ret;
            }
        }

        //ディレクトリのコピー
        void DirectoryCopy(string sourcePath, string destinationPath)
        {
            DirectoryInfo sourceDirectory = new DirectoryInfo(sourcePath);
            DirectoryInfo destinationDirectory = new DirectoryInfo(destinationPath);

            //コピー先のディレクトリがなければ作成する
            if (destinationDirectory.Exists == false)
            {
                destinationDirectory.Create();
                destinationDirectory.Attributes = sourceDirectory.Attributes;
            }

            //ファイルのコピー
            foreach (FileInfo fileInfo in sourceDirectory.GetFiles())
            {
                //同じファイルが存在していたら、常に上書きする
                fileInfo.CopyTo(destinationDirectory.FullName + @"\" + fileInfo.Name, true);
            }

            //ディレクトリのコピー（再帰を使用）
            foreach (System.IO.DirectoryInfo directoryInfo in sourceDirectory.GetDirectories())
            {
                DirectoryCopy(directoryInfo.FullName, destinationDirectory.FullName + @"\" + directoryInfo.Name);
            }
        }

        String fileNameConvert(Int64 camNo, String passName)
        {
            String fileName;
            String camName;

            fileName = Path.GetFileName(passName);
            camName = String.Format("{0:D3}", camNo);
            fileName = camName + "_" + Path.GetFileName(passName);

            return fileName;
        }

        void fileCopy(Int64 camNo, String passName, String dstDirName)
        {
            FileInfo fi;
            String newfileName;
            String dstfileName;

            // ファイルがないと処理がとまってしまうのでチェックを入れる。
            if (System.IO.File.Exists(passName) == false)
            {   // ファイルがなかったらコピー処理をやめる
                return;
            }

            // FileInfoオブジェクトの生成
            fi = new System.IO.FileInfo(passName);

            // ファイル名変換
            newfileName = fileNameConvert(camNo, passName);     // カメラ番号を付与したファイル名を作成
            dstfileName = dstDirName + "/" + newfileName;       // 格納先ファイル名の作成

            // ファイルコピー
            FileInfo copyFile = fi.CopyTo(dstfileName);         // ファイルのコピー
        }        
#endif

        void exportInfoSave(string filePass)
        {
            ConvertDataTableToCsv(rtDataTable, filePass, true);
        }

        void ExportButton_Click(object sender, RoutedEventArgs e)
        {
            // アラーム画像を特定のディレクトリに格納する
            // rtDataTable より情報を獲得するので、Loadボタンクリック後に
            // 正しい情報が出てくる（ExportボタンのEnb/Dis制御がBetter) 

            Int64 camNo;
            String passName;
            bool bDir = true;

            // 前準備
            //DirectoryDelete(EXP_FILE_PATH);                           // 不要データの削除
            //DirectoryMake(EXP_FILE_PATH);                             // 格納ディレクトリの作成
            //DirectoryMake(ALM_FILE_PATH);                             // 格納ディレクトリの作成
            //DirectoryMake(REG_FILE_PATH);                             // 格納ディレクトリの作成
            // export　ディレクトリがないときは作る。ある時はAlarmとthumbnailを削除する
            if (Directory.Exists(EXP_FILE_PATH) == true)
            {
                // ./export/thumbnailの削除
                bDir = FileAccess.Instance.DirectoryDelete(ALM_FILE_PATH);  // 不要データの削除(thumbnail)
                if (bDir == false)
                {
                    //メッセージボックスを表示する
                    System.Windows.Forms.MessageBox.Show("Export Incompleted(thumbnail delete) !!", "Export", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                // ./export/alarmの削除
                bDir = FileAccess.Instance.DirectoryDelete(REG_FILE_PATH);    // 不要データの削除(alarm)
                if (bDir == false)
                {
                    //メッセージボックスを表示する
                    System.Windows.Forms.MessageBox.Show("Export Incompleted(Alarm delete) !!", "Export", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                // rtinfo.csv の削除
                if (File.Exists(EXP_INFO_FILE_PATH) == true)
                {
                    try
                    {
                        File.Delete(EXP_INFO_FILE_PATH);
                    }
                    catch
                    {
                        //メッセージボックスを表示する
                        System.Windows.Forms.MessageBox.Show("Export Incompleted(rtinfo delete) !!", "Export", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }
            }
            bDir = FileAccess.Instance.DirectoryMake(ALM_FILE_PATH);    // 格納ディレクトリの作成(thumbnail)
            if (bDir == false)
            {
                //メッセージボックスを表示する
                System.Windows.Forms.MessageBox.Show("Export Incompleted(thumbnail make) !!", "Export", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            bDir = FileAccess.Instance.DirectoryMake(REG_FILE_PATH);    // 格納ディレクトリの作成(Alarm)
            if (bDir == false)
            {
                //メッセージボックスを表示する
                System.Windows.Forms.MessageBox.Show("Export Incompleted(alarm make) !!", "Export", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // CSVの作成
            exportInfoSave(EXP_INFO_FILE_PATH);

            // ファイルのコピー     thumbnail
            foreach (DataRow drow in rtDataTable.Rows)
            {
                camNo = (Int64)drow["CameraNo"];                                // カメラ番号の獲得
                passName = (String)drow["AlmFace"];                             // アラーム画像ファイルパスの獲得
                FileAccess.Instance.fileCopy(camNo, passName, ALM_FILE_PATH);   // ファイルのコピー
            }

            Int64 detId;
            String regpassName;
            // ファイルのコピー     alarm
            foreach (DataRow almdrow in almDataTable.Rows)
            {
                detId = (Int64)almdrow["DetectId"];                             // カメラ番号の獲得
                regpassName = (String)almdrow["RegFace"];                       // アラーム画像ファイルパスの獲得
                FileAccess.Instance.fileCopy(detId, regpassName, REG_FILE_PATH);// ファイルのコピー
            }

            //メッセージボックスを表示する
            System.Windows.Forms.MessageBox.Show("Export Completed !!", "Export", MessageBoxButtons.OK, MessageBoxIcon.Information);


        }

        /// <summary>
        /// DataTableの内容をCSVファイルに保存する
        /// </summary>
        /// <param name="dt">CSVに変換するDataTable</param>
        /// <param name="csvPath">保存先のCSVファイルのパス</param>
        /// <param name="writeHeader">ヘッダを書き込む時はtrue。</param>
        public void ConvertDataTableToCsv(
            DataTable dt, string csvPath, bool writeHeader)
        {
            //CSVファイルに書き込むときに使うEncoding
            System.Text.Encoding enc =
                System.Text.Encoding.GetEncoding("Shift_JIS");

            //書き込むファイルを開く
            System.IO.StreamWriter sr =
                new System.IO.StreamWriter(csvPath, false, enc);

            int colCount = dt.Columns.Count;
            int lastColIndex = colCount - 1;

            //ヘッダを書き込む
            if (writeHeader)
            {
                for (int i = 0; i < colCount; i++)
                {
                    //ヘッダの取得
                    string field = dt.Columns[i].Caption;
                    //"で囲む
                    field = EncloseDoubleQuotesIfNeed(field);
                    //フィールドを書き込む
                    sr.Write(field);
                    //カンマを書き込む
                    if (lastColIndex > i)
                    {
                        sr.Write(',');
                    }
                }
                //改行する
                sr.Write("\r\n");
            }

            //レコードを書き込む
            foreach (DataRow row in dt.Rows)
            {
                for (int i = 0; i < colCount; i++)
                {
                    //フィールドの取得
                    string field = row[i].ToString();
                    //"で囲む
                    field = EncloseDoubleQuotesIfNeed(field);
                    //フィールドを書き込む
                    sr.Write(field);
                    //カンマを書き込む
                    if (lastColIndex > i)
                    {
                        sr.Write(',');
                    }
                }
                //改行する
                sr.Write("\r\n");
            }

            //閉じる
            sr.Close();
        }

        /// <summary>
        /// 必要ならば、文字列をダブルクォートで囲む
        /// </summary>
        private string EncloseDoubleQuotesIfNeed(string field)
        {
            if (NeedEncloseDoubleQuotes(field))
            {
                return EncloseDoubleQuotes(field);
            }
            return field;
        }

        /// <summary>
        /// 文字列をダブルクォートで囲む
        /// </summary>
        private string EncloseDoubleQuotes(string field)
        {
            if (field.IndexOf('"') > -1)
            {
                //"を""とする
                field = field.Replace("\"", "\"\"");
            }
            return "\"" + field + "\"";
        }

        /// <summary>
        /// 文字列をダブルクォートで囲む必要があるか調べる
        /// </summary>
        private bool NeedEncloseDoubleQuotes(string field)
        {
            return field.IndexOf('"') > -1 ||
                field.IndexOf(',') > -1 ||
                field.IndexOf('\r') > -1 ||
                field.IndexOf('\n') > -1 ||
                field.StartsWith(" ") ||
                field.StartsWith("\t") ||
                field.EndsWith(" ") ||
                field.EndsWith("\t");
        }

        private void mappingClear()
        {
            if (bLoadMap == true)
            {
                Console.WriteLine(" ----- Load Data View -----");
                // Load Dataは、C:/ASF900/img/ 以下のデータ
                // アクセスを解放できるか？
                // こっちは何もしなくても不都合はない
            }
            if (bInportMap == true)
            {
                Console.WriteLine("----- Import Data View -----");
                // Inport Dataは、./export 以下のデータ
                // こっちはアクセスを解放しないと ./exportの再構成ができない
            }
            m_mapping.Clear();                              // マッピング初期化

            // ガベージコレクション                                     // 2013.11.19 ishi11
            GC.Collect();                                               // 2013.11.19 ishi11

            m_listView.ItemsSource = Mapping;               // マッピングアイテムの表示
        }

        private void faceAlarmDateRangeInit()
        {
            ucAlarmDateRange.TxtFrom.Text = "";
            ucAlarmDateRange.TxtTo.Text = "";
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            // Export ボタン無効
            ExportButton.IsEnabled = false;

            // Next/Previous ボタン無効
            skipButton(false);

            // アラーム件数表示初期化
            //TAlarmNo.Content = "";
            pageViewInit();

            mappingClear();                                 // マッピング初期化()

            // Mappingソース識別
            bLoadMap = false;
            bInportMap = false;

            // 日付範囲初期化
            faceAlarmDateRangeInit();
        }

        private void NextButton_Click(object sender, RoutedEventArgs e)
        {
            // Next/Previous ボタン無効
            skipButton(false);

            if (endPtr < totalPtr)
            {
                startPtr = endPtr++;
                if (viewPointerGet(startPtr) == true)
                {
                    readPtr = startPtr;
                    if (bInportMap == true)
                    {
                        mapView(impDataTable, startPtr, endPtr);
                    }
                    else if (bLoadMap == true)
                    {
                        mapView(rtDataTable, startPtr, endPtr);
                    }
                }
            }

            // Next/Previous ボタン有効
            skipButton(true);

            return;
        }

        private void PrevButton_Click(object sender, RoutedEventArgs e)
        {
            // Next/Previous ボタン無効
            skipButton(false);

            if (startPtr > 1)
            {
                if (startPtr <= PAGE_LIMIT_DATA)
                {
                    startPtr = 1;
                }
                else
                {
                    startPtr -= PAGE_LIMIT_DATA;
                }
                if (viewPointerGet(startPtr) == true)
                {
                    readPtr = startPtr;
                    if (bInportMap == true)
                    {
                        mapView(impDataTable, startPtr, endPtr);
                    }
                    else if (bLoadMap == true)
                    {
                        mapView(rtDataTable, startPtr, endPtr);
                    }
                }
            }

            // Next/Previous ボタン有効
            skipButton(true);
            return;
        }

        private void AlarmNo_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            // データ入力中に＜Enter＞がきたら 画面表示させる
            if (e.Key == Key.Return)
            {
                // Input data check
                if (AlarmNo.Text == "")
                {
                    return;
                }

                // Next/Previous ボタン無効
                skipButton(false);

                Int32 ptr = Convert.ToInt32(AlarmNo.Text);
                if (ptr == 0) { ptr++; }

                if (viewPointerGet(ptr) == true)
                {
                    startPtr = ptr;
                    readPtr = ptr;
                    if (bInportMap == true)
                    {
                        mapView(impDataTable, startPtr, endPtr);
                    }
                    else if (bLoadMap == true)
                    {
                        mapView(rtDataTable, startPtr, endPtr);
                    }
                }

                // Next/Previous ボタン有効
                skipButton(true);
            }
        }

        //
        // -------------- Tab(FaceDBDelete) 顔データ初期化 ---------
        //
        public void LogWriteToText(string strdata)
        {
            proclog += strdata;
            proclog += "\r\n";
            //TxtLogData.Text += strdata;
            //TxtLogData.Text += "\r\n";
        }

        // Test for Debug
        private void insertOMM1(object sender, RoutedEventArgs e)
        {
            // Progressbar の設定
            //progressBarAll.Minimum = 0;
            //progressBarAll.Maximum = TESTCNTMAX;
            //progressBarAll.Value = 0;
            // Background の設定
            WorkerAll = new System.ComponentModel.BackgroundWorker();

            if (TESTDTMAKE == 1)
            {
                // Background の設定
                WorkerAll.DoWork += new System.ComponentModel.DoWorkEventHandler(WorkerAll_DoWork);
                WorkerAll.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(WorkerAll_ProgressChanged);
                WorkerAll.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(WorkerAll_RunWorkerCompleted);
                // 進捗状況の報告をできるようにする
                WorkerAll.WorkerReportsProgress = true;
                // バックグラウンド処理の実行
                WorkerAll.RunWorkerAsync();
            }
            else
            {
                // Background の設定
                WorkerAll.DoWork += new System.ComponentModel.DoWorkEventHandler(WorkerFcopy_DoWork);
                WorkerAll.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(WorkerFcopy_ProgressChanged);
                WorkerAll.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(WorkerFcopy_RunWorkerCompleted);
                // 進捗状況の報告をできるようにする
                WorkerAll.WorkerReportsProgress = true;
                // バックグラウンド処理の実行
                WorkerAll.RunWorkerAsync();
                sALLflag = STS_OK;
            }
        }

        private void deleteMM1(object sender, RoutedEventArgs e)
        {
            // Progressbar の設定
            //progressBarMM1.Minimum = 0;
            //progressBarMM1.Maximum = TESTCNTMAX;
            //progressBarMM1.Value = 0;
            // Background の設定
            WorkerMM = new System.ComponentModel.BackgroundWorker();
            WorkerMM.DoWork += new System.ComponentModel.DoWorkEventHandler(WorkerMM_DoWork);
            WorkerMM.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(WorkerMM_ProgressChanged);
            WorkerMM.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(WorkerMM_RunWorkerCompleted);
            // 進捗状況の報告をできるようにする
            WorkerMM.WorkerReportsProgress = true;
            // バックグラウンド処理の実行
            WorkerMM.RunWorkerAsync();

        }

        private void deleteOMM1(object sender, RoutedEventArgs e)
        {
            // Progressbar の設定
            //progressBarOMM1.Minimum = 0;
            //progressBarOMM1.Maximum = TESTCNTMAX;
            //progressBarOMM1.Value = 0;
            // Background の設定
            WorkerOMM1 = new System.ComponentModel.BackgroundWorker();
            WorkerOMM1.DoWork += new System.ComponentModel.DoWorkEventHandler(WorkerOMM1_DoWork);
            WorkerOMM1.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(WorkerOMM1_ProgressChanged);
            WorkerOMM1.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(WorkerOMM1_RunWorkerCompleted);
            // 進捗状況の報告をできるようにする
            WorkerOMM1.WorkerReportsProgress = true;
            // バックグラウンド処理の実行
            WorkerOMM1.RunWorkerAsync();

        }

        private void deleteOMM2(object sender, RoutedEventArgs e)
        {
            // Progressbar の設定
            //progressBarOMM2.Minimum = 0;
            //progressBarOMM2.Maximum = TESTCNTMAX;
            //progressBarOMM2.Value = 0;
            // Background の設定
            WorkerOMM2 = new System.ComponentModel.BackgroundWorker();
            WorkerOMM2.DoWork += new System.ComponentModel.DoWorkEventHandler(WorkerOMM2_DoWork);
            WorkerOMM2.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(WorkerOMM2_ProgressChanged);
            WorkerOMM2.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(WorkerOMM2_RunWorkerCompleted);
            // 進捗状況の報告をできるようにする
            WorkerOMM2.WorkerReportsProgress = true;
            // バックグラウンド処理の実行
            WorkerOMM2.RunWorkerAsync();

        }

        private void deleteOMM3(object sender, RoutedEventArgs e)
        {
            // Progressbar の設定
            //progressBarOMM3.Minimum = 0;
            //progressBarOMM3.Maximum = TESTCNTMAX;
            //progressBarOMM3.Value = 0;
            // Background の設定
            WorkerOMM3 = new System.ComponentModel.BackgroundWorker();
            WorkerOMM3.DoWork += new System.ComponentModel.DoWorkEventHandler(WorkerOMM3_DoWork);
            WorkerOMM3.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(WorkerOMM3_ProgressChanged);
            WorkerOMM3.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(WorkerOMM3_RunWorkerCompleted);
            // 進捗状況の報告をできるようにする
            WorkerOMM3.WorkerReportsProgress = true;
            // バックグラウンド処理の実行
            WorkerOMM3.RunWorkerAsync();

        }


        private bool deleteDataBaseCheck()
        {
            bool fRet = false;

            if ((sMMflag == STS_OK)
                && (sOMM1flag == STS_OK)
                && (sOMM2flag == STS_OK)
                && (sOMM3flag == STS_OK))
            {
                fRet = true;
            }

            return (fRet);
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            //InitializeComponent();

            // Label Clear
            // LblStatus.Content = String.Empty;
            //LblFcpOK.Content = String.Empty;
            //LblmddataOK.Content = String.Empty;
            //LbltmpRecOK.Content = String.Empty;
            //LblrtHistOK.Content = String.Empty;
            //LblrtmatchOK.Content = String.Empty;
            // Log data Clear
            //TxtLogData.Text = String.Empty;
            proclog = String.Empty;

            // ステータスの初期化
            sALLflag = STS_INIT;
            sMMflag = STS_INIT;
            sOMM1flag = STS_INIT;
            sOMM2flag = STS_INIT;
            sOMM3flag = STS_INIT;
            sFCPflag = STS_INIT;


            // ファイルコピーチェック
            //if (CbFcopy.IsChecked == true)
            //{
            //    bFcopy = true;
            //}
            //else
            //{
            //    bFcopy = false;
            //}


            // ボタンの無効化
            //BtnDelete.IsEnabled = false;

            // チェックボックスの無効化
            //CbFcopy.IsEnabled = false;

            // Process flag
            sALLflag = STS_INIT;
            sMMflag = STS_INIT;
            sOMM1flag = STS_INIT;
            sOMM2flag = STS_INIT;
            sOMM3flag = STS_INIT;

#if false
            // まず、ポップアップメッセージでほんとうに消去するのかを出す
            MessageBoxResult mbresult = MessageBox.Show("ボタンを選択", "タイトル", MessageBoxButtons.YesNo);
            if (mbresult != MessageBoxResult.OK)
            {
                return;
            }
#endif

            // Test for Debug
            insertOMM1(sender, e);

            // step1:   MMデータベース削除
            deleteMM1(sender, e);

            // step2:   OMMデータベース削除1
            deleteOMM1(sender, e);

            // step3:   OMMデータベース削除2
            deleteOMM2(sender, e);

            // step4:   OMMデータベース削除3
            // step5:   データベース削除チェック＆初期データコピー
            deleteOMM3(sender, e);

        }

        // ---------- << Background Process >> ---------- 
        // < OMM:Test >
        /// 時間のかかる処理を実行
        void WorkerAll_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            Int32 testcnt;
            string tstsqlOMM;
            NpgsqlCommand tstcmdOMM;
            Int32 tstrowsaffected;

            LogWriteToText("-------- Test start -------- ");
            // step1:   Database Connect
            connOMM = new NpgsqlConnection(sqlOMM);
            LogWriteToText("<Connect> - " + sqlOMM);
            connOMM.Open();
            LogWriteToText("OK\r\n");

            // step2:   Data Delete
            for (testcnt = 0; testcnt < TESTCNTMAX; testcnt++)
            {
                try
                {
                    // INSERT INTO tmp_receive_info(sensor_kind,sensor_data,send_time,tz,st,content_number,human_count_id,start_time,start_frame,area_id,delete_flag,create_user,create_datetime,update_user,update_datetime,rt_alarm_notice_flag) VALUES('aaaa',11111,'2013-10-18',0,0,222,333,'2013-10-18','100',200,'0',44444444,'2013-10-18',44444444,'2013-10-18','0')
                    tstsqlOMM = "INSERT INTO tmp_receive_info(sensor_kind,sensor_data,send_time,tz,st,content_number,human_count_id,start_time,start_frame,area_id,delete_flag,create_user,create_datetime,update_user,update_datetime,rt_alarm_notice_flag) ";
                    tstsqlOMM += "VALUES('aaaa',11111,'2013-10-18',0,0,222,333,'2013-10-18','100',200,'0',44444444,'2013-10-18',44444444,'2013-10-18','0')";
                    tstcmdOMM = new NpgsqlCommand(tstsqlOMM, connOMM);
                    tstrowsaffected = tstcmdOMM.ExecuteNonQuery();
                    if ((testcnt % TESTCNTDIV) == 0)
                    {   // 10000毎に値を更新
                        WorkerAll.ReportProgress(testcnt);
                        // 100mSecスリープ
                        System.Threading.Thread.Sleep(20);
                    }
                }
                catch (Exception ex)
                {
                    //メッセージボックスを表示する
                    System.Windows.Forms.MessageBox.Show(ex.Message, "TestData Make Error(OMM)", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    connOMM.Close();
                    LogWriteToText("Test data Making NG\r\n");
                    sALLflag = STS_NG;
                    testcnt = TESTCNTMAX;
                }
            }
            WorkerAll.ReportProgress(testcnt);

            // step3:   Database Disconnect
            connOMM.Close();
            LogWriteToText("<Close> - " + sqlOMM);
            LogWriteToText("-------- Test end --------");
        }

        /// 現在値の更新
        void WorkerAll_ProgressChanged(object sender, System.ComponentModel.ProgressChangedEventArgs e)
        {
            // プログレスバーの現在値を更新する
            //progressBarAll.Value = e.ProgressPercentage;
        }

        /// 「時間のかかる処理」終了時の処理
        void WorkerAll_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            LogWriteToText("-------- WorkerAll Completed --------\r\n");
            //TxtLogData.Text = proclog;
            if (sALLflag == STS_INIT)
            {
                sALLflag = STS_OK;
            }
        }

        // < MM >
        /// 時間のかかる処理を実行
        void WorkerMM_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            while (sALLflag == STS_INIT)
            {
                // 100mSecスリープ
                System.Threading.Thread.Sleep(20);
            }

            try
            {
                // MM Database Connect
                connMM = new NpgsqlConnection(sqlMM);
                LogWriteToText("<Connect> - " + sqlMM);
                connMM.Open();
                LogWriteToText("OK\r\n");

                // MM Database Delete
                NpgsqlCommand commandMM = new NpgsqlCommand(delsqlMM, connMM);
                LogWriteToText(delsqlMM);
                Int32 rowsaffected = commandMM.ExecuteNonQuery();
                LogWriteToText("OK\r\n");
                //LblmddataOK.Content = "OK";
            }
            catch (Exception ex)
            {
                LogWriteToText("Failed!!");
                //メッセージボックスを表示する
                System.Windows.Forms.MessageBox.Show(ex.Message, "DataBase Error(MM)", MessageBoxButtons.OK, MessageBoxIcon.Error);
                sMMflag = STS_NG;
            }
            connMM.Close();
            LogWriteToText("<Close> - " + sqlMM);
            WorkerMM.ReportProgress(TESTCNTMAX);
        }

        /// 現在値の更新
        void WorkerMM_ProgressChanged(object sender, System.ComponentModel.ProgressChangedEventArgs e)
        {
            // プログレスバーの現在値を更新する
            //progressBarMM1.Value = e.ProgressPercentage;
        }

        /// 「時間のかかる処理」終了時の処理
        void WorkerMM_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            LogWriteToText("-------- WorkerMM Completed --------\r\n");
            //TxtLogData.Text = proclog;
            if (sMMflag == STS_INIT)
            {
                //LblmddataOK.Content = "OK";
                sMMflag = STS_OK;
            }
        }

        // < OMM1 >
        /// 時間のかかる処理を実行
        void WorkerOMM1_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            while (sMMflag == STS_INIT)
            {
                // 100mSecスリープ
                System.Threading.Thread.Sleep(20);
            }

            try
            {
                // OMM Database Connect
                connOMM = new NpgsqlConnection(sqlOMM);
                LogWriteToText("<Connect> - " + sqlOMM);
                connOMM.Open();
                LogWriteToText("OK\r\n");

                NpgsqlCommand commandOMM = new NpgsqlCommand(delsqlOMM1, connOMM);
                LogWriteToText(delsqlOMM1);
                Int32 rowsaffected = commandOMM.ExecuteNonQuery();
                LogWriteToText("OK\r\n");
                //LbltmpRecOK.Content = "OK";
            }
            catch (Exception ex)
            {
                //メッセージボックスを表示する
                System.Windows.Forms.MessageBox.Show(ex.Message, "DataBase Error(OMM)", MessageBoxButtons.OK, MessageBoxIcon.Error);
                sOMM1flag = STS_NG;
            }
            connOMM.Close();
            LogWriteToText("<Close> - " + sqlMM);
            WorkerOMM1.ReportProgress(TESTCNTMAX);
        }

        /// 現在値の更新
        void WorkerOMM1_ProgressChanged(object sender, System.ComponentModel.ProgressChangedEventArgs e)
        {
            // プログレスバーの現在値を更新する
            //progressBarOMM1.Value = e.ProgressPercentage;
        }

        /// 「時間のかかる処理」終了時の処理
        void WorkerOMM1_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            LogWriteToText("-------- WorkerOMM1 Completed --------\r\n");
            //TxtLogData.Text = proclog;
            if (sOMM1flag == STS_INIT)
            {
                //LbltmpRecOK.Content = "OK";
                sOMM1flag = STS_OK;
            }
        }

        // < OMM2 >
        /// 時間のかかる処理を実行
        void WorkerOMM2_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            while (sOMM1flag == STS_INIT)
            {
                // 100mSecスリープ
                System.Threading.Thread.Sleep(20);
            }

            try
            {
                // OMM Database Connect
                connOMM = new NpgsqlConnection(sqlOMM);
                LogWriteToText("<Connect> - " + sqlOMM);
                connOMM.Open();
                LogWriteToText("OK\r\n");

                NpgsqlCommand commandOMM = new NpgsqlCommand(delsqlOMM2, connOMM);
                LogWriteToText(delsqlOMM2);
                Int32 rowsaffected = commandOMM.ExecuteNonQuery();
                LogWriteToText("OK\r\n");
                //LblrtHistOK.Content = "OK";
            }
            catch (Exception ex)
            {
                //メッセージボックスを表示する
                System.Windows.Forms.MessageBox.Show(ex.Message, "DataBase Error(OMM)", MessageBoxButtons.OK, MessageBoxIcon.Error);
                sOMM2flag = STS_NG;
            }
            connOMM.Close();
            LogWriteToText("<Close> - " + sqlMM);
            WorkerOMM2.ReportProgress(TESTCNTMAX);
        }

        /// 現在値の更新
        void WorkerOMM2_ProgressChanged(object sender, System.ComponentModel.ProgressChangedEventArgs e)
        {
            // プログレスバーの現在値を更新する
            //progressBarOMM2.Value = e.ProgressPercentage;
        }

        /// 「時間のかかる処理」終了時の処理
        void WorkerOMM2_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            LogWriteToText("-------- WorkerOMM2 Completed --------\r\n");
            //TxtLogData.Text = proclog;
            if (sOMM2flag == STS_INIT)
            {
                //LblrtHistOK.Content = "OK";
                sOMM2flag = STS_OK;
            }
        }

        // < OMM3 >
        /// 時間のかかる処理を実行
        void WorkerOMM3_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            while (sOMM2flag == STS_INIT)
            {
                // 100mSecスリープ
                System.Threading.Thread.Sleep(20);
            }

            try
            {
                // OMM Database Connect

                connOMM = new NpgsqlConnection(sqlOMM);
                LogWriteToText("<Connect> - " + sqlOMM);
                connOMM.Open();
                LogWriteToText("OK\r\n");

                NpgsqlCommand commandOMM = new NpgsqlCommand(delsqlOMM3, connOMM);
                LogWriteToText(delsqlOMM3);
                Int32 rowsaffected = commandOMM.ExecuteNonQuery();
                LogWriteToText("OK\r\n");
                //LblrtmatchOK.Content = "OK";
            }
            catch (Exception ex)
            {
                //メッセージボックスを表示する
                System.Windows.Forms.MessageBox.Show(ex.Message, "DataBase Error(OMM)", MessageBoxButtons.OK, MessageBoxIcon.Error);
                sOMM3flag = STS_NG;
            }
            connOMM.Close();
            LogWriteToText("<Close> - " + sqlMM);
            WorkerOMM3.ReportProgress(TESTCNTMAX);
        }

        /// 現在値の更新
        void WorkerOMM3_ProgressChanged(object sender, System.ComponentModel.ProgressChangedEventArgs e)
        {
            // プログレスバーの現在値を更新する
            //progressBarOMM3.Value = e.ProgressPercentage;
        }

        /// 「時間のかかる処理」終了時の処理
        void WorkerOMM3_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            LogWriteToText("-------- WorkerOMM3 Completed --------\r\n");
            if (sOMM3flag == STS_INIT)
            {
                //LblrtmatchOK.Content = "OK";
                sOMM3flag = STS_OK;
            }
            //TxtLogData.Text = proclog;

            // ボタンの有効化
            //BtnDelete.IsEnabled = true;

            if (deleteDataBaseCheck() == true)
            {
                LogWriteToText("The Face Database was successfully cleared.\r\n");
                //TxtLogData.Text = proclog;
                if (TESTDTMAKE == 1)
                {
                    // 初期データコピー処理
                    if (bFcopy == true)
                    {   // ファイルコピーのチェックボックスをチェック
                        LogWriteToText("Initial Data Copy Start");
                        FileAccess.Instance.DirectoryCopy(SRC_FILE_PATH, DST_FILE_PATH);
                        LogWriteToText("OK\r\n");
                        LogWriteToText("-------- WorkerFcopy Completed --------\r\n");
                        //LblFcpOK.Content = "OK";
                    }
                    if (deleteDataBaseCheck() == true)
                    {
                        //メッセージボックスを表示する
                        System.Windows.Forms.MessageBox.Show("Face Database Deleted", "Finished!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        //メッセージボックスを表示する
                        System.Windows.Forms.MessageBox.Show("Face Database Not Deleted", "Failed!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    //TxtLogData.Text = proclog;

                    // チェックボックスの有効化
                    //CbFcopy.IsEnabled = true;
                }
                else
                {
                    if (sOMM3flag == STS_INIT)
                    {
                        //LblrtmatchOK.Content = "OK";
                        sOMM3flag = STS_OK;
                    }
                }
            }
            else
            {
                // 初期データへのコピーは行わない
            }


            // ボタンの有効化              メッセージボックスの表示前に移動
            // BtnDelete.IsEnabled = true;

            // ファイルコピー開始
            sFCPflag = STS_OK;
        }

        // < File copy:Dummy >
        /// 時間のかかる処理を実行
        void WorkerFcopy_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            while (sFCPflag == STS_INIT)
            {
                // 100mSecスリープ
                System.Threading.Thread.Sleep(20);
            }

            // 初期データのコピー
            if (bFcopy == true)
            {   // ファイルコピーのチェックボックスをチェック
                LogWriteToText("Initial Data Copy Start");
                FileAccess.Instance.DirectoryCopy(SRC_FILE_PATH, DST_FILE_PATH);
                LogWriteToText("OK\r\n");
                // TESTDTMAKE=0 以外はこない
                //if (TESTDTMAKE == 0)
                //{   // コピー終了処理へ
                WorkerAll.ReportProgress(TESTCNTMAX);
                //}
            }

        }

        /// 現在値の更新
        void WorkerFcopy_ProgressChanged(object sender, System.ComponentModel.ProgressChangedEventArgs e)
        {
            // プログレスバーの現在値を更新する
            //progressBarAll.Value = e.ProgressPercentage;
        }

        /// 「時間のかかる処理」終了時の処理
        void WorkerFcopy_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            // チェックボックスの有効化
            //CbFcopy.IsEnabled = true;

            LogWriteToText("-------- WorkerFcopy Completed --------\r\n");
            if (deleteDataBaseCheck() == true)
            {
                if (bFcopy == true)
                {
                    //LblFcpOK.Content = "OK";
                }

                //メッセージボックスを表示する
                System.Windows.Forms.MessageBox.Show("Face Database Deleted", "Finished!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                //メッセージボックスを表示する
                System.Windows.Forms.MessageBox.Show("Face Database Not Deleted", "Failed!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            //TxtLogData.Text = proclog;

        }



        private void progressBarAll_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {

        }

        private void progressBarMM1_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {

        }

        private void progressBarOMM1_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {

        }

        private void progressBarOMM2_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {

        }

        private void progressBarOMM3_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {

        }

        private void CbFcopy_Checked(object sender, RoutedEventArgs e)
        {
            //bFcopy = true;
        }

        //
        // -------------- Tab(TmpRcvView) テンポラリ表示 ---------
        //  // 
        private void btnLoadFace_Click(object sender, RoutedEventArgs e)
        {
            // Mapping初期化
            faceMappingClear();

            if (LoadFaceThumbData() == false)
            {               
                return;
            }

            // Export ボタン無効
            //btnExport.IsEnabled = true;

            // Next/Prev ボタン有効
            skipThumbButton(true);

            //メッセージボックスを表示する
            System.Windows.Forms.MessageBox.Show("Load Completed !!", "Load", MessageBoxButtons.OK, MessageBoxIcon.Information);

            return;
        }

        void faceDateRangeInit()
        {
            //ucTmpDateRange.TxtFrom.Text = "";
            //ucTmpDateRange.TxtTo.Text = "";
        }

        private void btnClearFace_Click(object sender, RoutedEventArgs e)
        {
            // Mapping初期化
            faceMappingClear();

            // Export ボタン無効
            //btnExport.IsEnabled = false;
		
		    // Next/Prev ボタン無効
            skipThumbButton(false);
		
		    // 検出画像数表示初期化
		    //TFaceNo.Content = "";

		    // 時間範囲指定初期化
            faceDateRangeInit();
        }

        private void btnPrev_Click(object sender, RoutedEventArgs e)
        {
            // Next/Previous ボタン無効
            skipThumbButton(false);

            if (startFacePtr > 1)
            {
                if (startFacePtr <= FACE_PAGE_LIMIT_DATA)
                {
                    startFacePtr = 1;
                }
                else
                {
                    startFacePtr -= FACE_PAGE_LIMIT_DATA;
                }
                if (viewFacePointerGet(startFacePtr) == true)
                {
                    readFacePtr = startFacePtr;
                    mapFaceView(faceDataTable, startFacePtr, endFacePtr);
                }
            }

            // Next/Previous ボタン有効
            skipThumbButton(true);
            return;
        }

        private void btnNext_Click(object sender, RoutedEventArgs e)
        {
            // Next/Previous ボタン無効
            skipThumbButton(false);

            if (endFacePtr < totalFacePtr)
            {
                startFacePtr = endFacePtr++;
                if (viewFacePointerGet(startFacePtr) == true)
                {
                    readFacePtr = startFacePtr;
                    mapFaceView(faceDataTable, startFacePtr, endFacePtr);
                }
            }

            // Next/Previous ボタン有効
            skipThumbButton(true);

            return;

        }

        // Import削除(不要なので)
        //private void btnImport_Click(object sender, RoutedEventArgs e)
        //{
        //
        //}

        private void btnExport_Click(object sender, RoutedEventArgs e)
        {
            // 受信テンポラリ画像を特定のディレクトリに格納する
            // faceDataTable より情報を獲得するので、Loadボタンクリック後に
            // 正しい情報が出てくる（ExportボタンのEnb/Dis制御がBetter) 

            Int64 camNo;
            String passName;
            bool bDir = true;

            // 前準備
            //DirectoryDelete(EXP_FILE_PATH);                           // 不要データの削除
            //DirectoryMake(EXP_FILE_PATH);                             // 格納ディレクトリの作成
            //DirectoryMake(ALM_FILE_PATH);                             // 格納ディレクトリの作成
            //DirectoryMake(REG_FILE_PATH);                             // 格納ディレクトリの作成
            // export　ディレクトリがないときは作る。ある時はAlarmとthumbnailを削除する
            if (Directory.Exists(EXP_FILE_PATH) == true)
            {
                // ./export/tmprcvの削除
                bDir = FileAccess.Instance.DirectoryDelete(TMPRCV_FILE_PATH);  // 不要データの削除
                if (bDir == false)
                {
                    //メッセージボックスを表示する
                    System.Windows.Forms.MessageBox.Show("Export Incompleted(tmprcv delete) !!", "Export", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }
            else
            {
                bDir = FileAccess.Instance.DirectoryMake(EXP_FILE_PATH);    // 格納ディレクトリの作成(export)
                if (bDir == false)
                {
                    //メッセージボックスを表示する
                    System.Windows.Forms.MessageBox.Show("Export Incompleted(tmprcv make) !!", "Export", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

            }
            bDir = FileAccess.Instance.DirectoryMake(TMPRCV_FILE_PATH);    // 格納ディレクトリの作成(tmprcv)
            if (bDir == false)
            {
                //メッセージボックスを表示する
                System.Windows.Forms.MessageBox.Show("Export Incompleted(tmprcv make) !!", "Export", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // ファイルのコピー     tmprcv
            foreach (DataRow drow in faceDataTable.Rows)
            {
                camNo = (Int64)drow["CameraId"];                                // カメラ番号の獲得
                passName = (String)drow["DetFace"];                             // アラーム画像ファイルパスの獲得
                FileAccess.Instance.fileCopy(camNo, passName, TMPRCV_FILE_PATH);   // ファイルのコピー
            }

            //メッセージボックスを表示する
            System.Windows.Forms.MessageBox.Show("Export Completed !!", "Export", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        void faceDataTableInit()
        {
            //DataTable初期化
            if (faceDataTable != null)
            {
                DataRow[] rows;
                try
                {
                    rows = faceDataTable.Select();
                    Array.ForEach<DataRow>(rows, row => faceDataTable.Rows.Remove(row));
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine("Error face Delete " + ex.Message);
                }
                rows = null;
            }
        }

        void pageFaceViewInit()
        {
            readFacePtr = 0;
            startFacePtr = 0;
            endFacePtr = 0;
            totalFacePtr = 0;
            //TFaceNo.Content = "";
            //FaceNo.Text = "";
        }

        void totalFaceAdd()
        {
            totalFacePtr++;
            //TFaceNo.Content = totalFacePtr.ToString();
        }

        // Page View ボタン制御
        private void skipThumbButton(bool status)
        {
            //btnNext.IsEnabled = status;
            //btnPrev.IsEnabled = status;
        }
        private void nextThumbButton(bool status)
        {
            //btnNext.IsEnabled = status;
        }
        private void prevThumbButton(bool status)
        {
            //btnPrev.IsEnabled = status;
        }

        private bool LoadFaceThumbData()
        {
            bool ret = false;

#if false
            // パラメータをチェックしてSQLコマンドを決定する
            // camera_id            0
            // send_time            1
            // bs_score_1           2
            // bs_score_2           3
            // thumbnail_file_path  4
            String sql = CheckInputData();
            //System.Windows.Forms.MessageBox.Show("CheckInputData", "LoadFaceThumbData", MessageBoxButtons.OK, MessageBoxIcon.Information);  // debug 2013.11.29 ishi11
            if (null == sql)
            {
                // エラー詳細は関数内部でメッセージをだすことにするので
                // ここでは戻るだけ
                return ret;
            }
#endif

            //DataTable初期化
            faceDataTableInit();
            //System.Windows.Forms.MessageBox.Show("faceDataTableInit", "LoadFaceThumbData", MessageBoxButtons.OK, MessageBoxIcon.Information);  // debug 2013.11.29 ishi11

            // 初期データ設定
            pageFaceViewInit();
            //System.Windows.Forms.MessageBox.Show("pageFaceViewInit", "LoadFaceThumbData", MessageBoxButtons.OK, MessageBoxIcon.Information);  // debug 2013.11.29 ishi11

            //PostgreSQLに接続
            NpgsqlConnection conn = new NpgsqlConnection(sqlOMM);
            try
            {
                conn.Open();
            }
            catch (Exception ex)
            {
                //メッセージボックスを表示する
                System.Windows.Forms.MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return ret;
            }
            //System.Windows.Forms.MessageBox.Show("DB connect", "LoadFaceThumbData", MessageBoxButtons.OK, MessageBoxIcon.Information);  // debug 2013.11.29 ishi11

#if true
            // パラメータをチェックしてSQLコマンドを決定する
            // camera_id            0
            // send_time            1
            // bs_score_1           2
            // bs_score_2           3
            // thumbnail_file_path  4
            //String sql = CheckInputData();
            String sql = "select camera_id, send_time, bs_score_1, bs_score_2, thumbnail_file_path from tmp_receive_info";
            //sql = CheckInputData(sql, ucTmpDateRange.TxtFrom.Text, ucTmpDateRange.TxtTo.Text);
            //sql = CheckInputData(sql, "send_time", ucTmpDateRange.TxtFrom.Text, ucTmpDateRange.TxtTo.Text);
            //System.Windows.Forms.MessageBox.Show("CheckInputData", "LoadFaceThumbData", MessageBoxButtons.OK, MessageBoxIcon.Information);  // debug 2013.11.29 ishi11
            if (null == sql)
            {
                // エラー詳細は関数内部でメッセージをだすことにするので
                // ここでは戻るだけ
                return ret;
            }

            //　コマンドを生成
            //NpgsqlCommand cmd = SetParameter(conn, sql);
            //NpgsqlCommand cmd = SetParameter(conn, sql, ucTmpDateRange.TxtFrom.Text, ucTmpDateRange.TxtTo.Text);
#else
            // コマンドを生成
            NpgsqlCommand cmd = new NpgsqlCommand(sql, conn);
            //System.Windows.Forms.MessageBox.Show("DB command", "LoadFaceThumbData", MessageBoxButtons.OK, MessageBoxIcon.Information);  // debug 2013.11.29 ishi11
#endif

            try
            {
                // rt_alarm_history を読み出して Datatableに必要な情報をセットする
                //NpgsqlDataReader dr = cmd.ExecuteReader();
                DataRow rowInfo;
                Int64 camera_id;
                String send_time;
                Int16 bs_score_1;
                Int16 bs_score_2;
                String thumbnail_file_path;

                //System.Windows.Forms.MessageBox.Show("DB cmd execute", "LoadFaceThumbData", MessageBoxButtons.OK, MessageBoxIcon.Information);  // debug 2013.11.29 ishi11

                //while (dr.Read())
                //{
                    //if (TEST_THUMB_DTMAKE == 0)
                    //{
                //        camera_id = dr.GetInt64(0);
                //        send_time = DateTimeUtil.ConvUTCToLocalDateTime(dr.GetDateTime(1)).ToString();
                //        bs_score_1 = dr.GetInt16(2);
                //        bs_score_2 = dr.GetInt16(3);
                //        thumbnail_file_path = dr.GetString(4);
                        //System.Windows.Forms.MessageBox.Show("DB read", "LoadFaceThumbData", MessageBoxButtons.OK, MessageBoxIcon.Information);  // debug 2013.11.29 ishi11
                    //}
                    //else
                    //{   // rt_alarm_matching_infoなので
                    //    camera_id = dr.GetInt64(0);                         // rt_alarm_matching_info_id
                    //    send_time = DateTimeUtil.ConvUTCToLocalDateTime(dr.GetDateTime(11)).ToString();
                    //    // create_datetime
                    //    bs_score_1 = dr.GetInt16(1);                        // user_id
                    //    bs_score_2 = dr.GetInt16(3);                        // matching_st
                    //    thumbnail_file_path = dr.GetString(2);              // thumbnail_file_path
                    //}

                //    rowInfo = faceDataTable.NewRow();
                //    rowInfo["CameraId"] = camera_id;                        // CameraId
                //    rowInfo["Date"] = send_time;                            // Date
                //    rowInfo["DetFace"] = thumbnail_file_path;               // DetFace
                //    faceDataTable.Rows.Add(rowInfo);
                //}
                //System.Windows.Forms.MessageBox.Show("DataTable write end", "LoadFaceThumbData", MessageBoxButtons.OK, MessageBoxIcon.Information);  // debug 2013.11.29 ishi11

                // 検出件数チェック
                foreach (DataRow drow2 in faceDataTable.Rows)
                {
                    totalFaceAdd();
                }
                //System.Windows.Forms.MessageBox.Show("TotalFace", "LoadFaceThumbData", MessageBoxButtons.OK, MessageBoxIcon.Information);  // debug 2013.11.29 ishi11

                //if (FaceNo.Text != "")
                //{   // 番号指定
                //    try
                //    {
                //        readFacePtr = Convert.ToInt32(FaceNo.Text);
                //    }
                //    catch
                //    {   // 再入力
                //        System.Windows.Forms.MessageBox.Show("Face no. Illegal !!", "Import", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //        return ret;
                //    }
                //}
                //else
                //{   // 最初から
                //    readFacePtr++;
                //}
                startFacePtr = readFacePtr;
                if (viewFacePointerGet(startFacePtr) == false)
                {
                    System.Windows.Forms.MessageBox.Show("Face data Nothing !!", "Import", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    ret = true;
                }
                //System.Windows.Forms.MessageBox.Show("viewFacePointerGet", "LoadFaceThumbData", MessageBoxButtons.OK, MessageBoxIcon.Information);  // debug 2013.11.29 ishi11
                mapFaceView(faceDataTable, startFacePtr, endFacePtr);
                //System.Windows.Forms.MessageBox.Show("mapFaceView", "LoadFaceThumbData", MessageBoxButtons.OK, MessageBoxIcon.Information);  // debug 2013.11.29 ishi11

                conn.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message, "Import", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                conn.Close();
            }
            //System.Windows.Forms.MessageBox.Show("DB disconnect", "LoadFaceThumbData", MessageBoxButtons.OK, MessageBoxIcon.Information);  // debug 2013.11.29 ishi11

            //m_face_listView.ItemsSource = FaceMapping;
            //System.Windows.Forms.MessageBox.Show("m_face_listView", "LoadFaceThumbData", MessageBoxButtons.OK, MessageBoxIcon.Information);  // debug 2013.11.29 ishi11

            return ret;
        }

        public bool CheckDateRange(string strTxtDate)
        {
            bool retsts = false;

            if (System.Text.RegularExpressions.Regex.IsMatch(strTxtDate, @"^\d{4}/\d{2}/\d{2} \d{2}:\d{2}$",
                                                            System.Text.RegularExpressions.RegexOptions.ECMAScript))
            {
                try
                {
                    DateTime dt = DateTime.Parse(strTxtDate + ":00");
                    retsts = true;
                }
                catch
                {
                    return retsts;
                }
            }
            return retsts;
        }

        //private String CheckInputData()
        private String CheckInputData(String sql, string order, string strTxtFrom, string strTxtTo)
        {
            Boolean whereFlag = false;

#if true
            if (strTxtFrom.Length > 0)
            {
                if (CheckDateRange(strTxtFrom) == false)
                {
                    System.Windows.Forms.MessageBox.Show("'From' is invalid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return null;
                }
                if (whereFlag)
                {
                    sql = sql + " and";
                }
                else
                {
                    sql = sql + " where";
                }
                //sql = sql + " to_char(send_time, 'YYYY/MM/DD HH24:MI') >= :from";
                sql = sql + " to_char(" + order;
                sql = sql + ", 'YYYY/MM/DD HH24:MI') >= :from";
                whereFlag = true;
            }

            if (strTxtTo.Length > 0)
            {
                if (CheckDateRange(strTxtTo) == false)
                {
                    System.Windows.Forms.MessageBox.Show("'To' is invalid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return null;
                }
                if (whereFlag)
                {
                    sql = sql + " and";
                }
                else
                {
                    sql = sql + " where";
                }
                //sql = sql + " to_char(send_time, 'YYYY/MM/DD HH24:MI') <= :to";
                sql = sql + " to_char(" + order;
                sql = sql + ", 'YYYY/MM/DD HH24:MI') <= :to";
                whereFlag = true;
            }
#else
            //if (ucTmpDateRange.TxtFrom.Text.Length > 0)
            if (strTxtFrom.Length > 0)
            {
                //if (System.Text.RegularExpressions.Regex.IsMatch(ucTmpDateRange.TxtFrom.Text, @"^\d{4}/\d{2}/\d{2} \d{2}:\d{2}$",
                if (System.Text.RegularExpressions.Regex.IsMatch(strTxtFrom, @"^\d{4}/\d{2}/\d{2} \d{2}:\d{2}$",
                        System.Text.RegularExpressions.RegexOptions.ECMAScript))
                {
                    try
                    {
                        //DateTime dt = DateTime.Parse(ucTmpDateRange.TxtFrom.Text + ":00");
                        DateTime dt = DateTime.Parse(strTxtFrom + ":00");
                    }
                    catch
                    {
                        //メッセージボックスを表示する
                        System.Windows.Forms.MessageBox.Show("'From' is invalid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return null;
                    }


                    if (whereFlag)
                    {
                        sql = sql + " and";
                    }
                    else
                    {
                        sql = sql + " where";
                    }
                    sql = sql + " to_char(send_time, 'YYYY/MM/DD HH24:MI') >= :from";
                    whereFlag = true;
                }
                else
                {
                    //メッセージボックスを表示する
                    System.Windows.Forms.MessageBox.Show("'From' is invalid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return null;
                }
            }

            //if (ucTmpDateRange.TxtTo.Text.Length > 0)
            if (strTxtTo.Length > 0)
            {
                //if (System.Text.RegularExpressions.Regex.IsMatch(ucTmpDateRange.TxtTo.Text, @"^\d{4}/\d{2}/\d{2} \d{2}:\d{2}$",
                if (System.Text.RegularExpressions.Regex.IsMatch(strTxtTo, @"^\d{4}/\d{2}/\d{2} \d{2}:\d{2}$",
                         System.Text.RegularExpressions.RegexOptions.ECMAScript))
                {
                    try
                    {
                        //DateTime dt = DateTime.Parse(ucTmpDateRange.TxtTo.Text + ":00");
                        DateTime dt = DateTime.Parse(strTxtTo + ":00");
                    }
                    catch
                    {
                        //メッセージボックスを表示する
                        System.Windows.Forms.MessageBox.Show("'To' is invalid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return null;
                    }

                    if (whereFlag)
                    {
                        sql = sql + " and";
                    }
                    else
                    {
                        sql = sql + " where";
                    }
                    sql = sql + " to_char(send_time, 'YYYY/MM/DD HH24:MI') <= :to";
                    whereFlag = true;
                }
                else
                {
                    //メッセージボックスを表示する
                    System.Windows.Forms.MessageBox.Show("'To' is invalid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return null;
                }
            }
#endif

            if (whereFlag == false)
            {
                //sql += "select * from tmp_receive_info";
            }
            else
            {
                //sql = sql + " order by send_time desc";
                sql = sql + " order by " + order + " desc";
            }

            // テスト時のみ、条件が真になります
            //if (TEST_THUMB_DTMAKE == 1)
            //{
            //    sql = "select * from rt_alarm_matching_info";
            //}

            //System.Windows.Forms.MessageBox.Show(sql, "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return sql;
        }

        //private NpgsqlCommand SetParameter(NpgsqlConnection conn, String sql)
        private NpgsqlCommand SetParameter(NpgsqlConnection conn, String sql, string strTxtFrom, string strTxtTo)
        {
            NpgsqlCommand command = new NpgsqlCommand(sql, conn);

            //if (ucTmpDateRange.TxtFrom.Text.Length > 0)
            if (strTxtFrom.Length > 0)
            {
                command.Parameters.Add(new NpgsqlParameter("from", DbType.String));
            }

            //if (ucTmpDateRange.TxtTo.Text.Length > 0)
            if (strTxtTo.Length > 0)
            {
                command.Parameters.Add(new NpgsqlParameter("to", DbType.String));
            }

            command.Prepare();

            //if (ucTmpDateRange.TxtFrom.Text.Length > 0)
            if (strTxtFrom.Length > 0)
            {
                //command.Parameters["from"].Value = DateTimeUtil.ConvLocalToUTCDateTime(ucTmpDateRange.TxtFrom.Text + ":00").ToString("yyyy/MM/dd HH:mm");
                command.Parameters["from"].Value = DateTimeUtil.ConvLocalToUTCDateTime(strTxtFrom + ":00").ToString("yyyy/MM/dd HH:mm");
            }

            //if (ucTmpDateRange.TxtTo.Text.Length > 0)
            if (strTxtTo.Length > 0)
            {
                //command.Parameters["to"].Value = DateTimeUtil.ConvLocalToUTCDateTime(ucTmpDateRange.TxtTo.Text + ":00").ToString("yyyy/MM/dd HH:mm");
                command.Parameters["to"].Value = DateTimeUtil.ConvLocalToUTCDateTime(strTxtTo + ":00").ToString("yyyy/MM/dd HH:mm");
            }


            //System.Windows.Forms.MessageBox.Show(command.CommandText, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return command;
        }

        private void faceMappingClear()
        {
            Console.WriteLine(" ----- Load Data View -----");

            m_face_mapping.Clear();                                 // マッピング初期化

            // ガベージコレクション
            GC.Collect(); 

            //m_face_listView.ItemsSource = FaceMapping;              // マッピングアイテムの表示
        }

        private void mapFaceView(DataTable dt, Int32 readStart, Int32 readEnd)
        {

            // マッピングアイテムに設定する
            Int64 camera_id;
            String send_time;
            String thumbnail_file_path;
            Int32 sttcnt = readStart - 1;
            Int32 endcnt = readEnd - 1;

            // ---<< Exportされたデータの表示>>---
            m_face_mapping.Clear();                                 // マッピング初期化

            // ガベージコレクション
            GC.Collect();

            // 行数分のマッピングアイテム設定を実施
            Int32 cnt;
            DataRow draw;
            for (cnt = sttcnt; cnt < endcnt; cnt++)
            {
                draw = dt.Rows[cnt];
                camera_id = (Int64)draw["CameraId"];
                send_time = (String)draw["Date"];
                thumbnail_file_path = (String)draw["DetFace"];
                // マッピングアイテムの設定(１行)
                FaceMappingItem item = new FaceMappingItem((cnt + 1), thumbnail_file_path, camera_id, send_time);
                m_face_mapping.Add(item);
            }

            // マッピングアイテムの表示
            //m_face_listView.ItemsSource = FaceMapping;
        }

        bool viewFacePointerGet(Int32 ptr)
        {
            bool ret = false;
            if (ptr > totalFacePtr)
            {   // Warning
            }
            else
            {
                endFacePtr = ptr + FACE_PAGE_LIMIT_DATA;
                if (endFacePtr > totalFacePtr)
                {
                    endFacePtr = totalFacePtr + 1;
                }
                ret = true;
            }
            return ret;
        }

        private void FaceNo_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            // データ入力中に＜Enter＞がきたら 画面表示させる
            if (e.Key == Key.Return)
            {
                // Input data check
                //if (FaceNo.Text == "")
                //{
                //    return;
                //}

                // Next/Previous ボタン無効
                skipThumbButton(false);

                //Int32 ptr = Convert.ToInt32(FaceNo.Text);
                //if (ptr == 0) { ptr++; }
                //if (viewFacePointerGet(ptr) == true)
                //{
                //    startFacePtr = ptr;
                //    readFacePtr = ptr;
                //    mapFaceView(faceDataTable, startFacePtr, endFacePtr);
                //}

                // Next/Previous ボタン有効
                skipThumbButton(true);
            }

        }

        //
        // -------------- Tab(ImageView) テンポラリ表示 ---------
        // 
        public const int IMAGE_THUMB = 0;
        public const int IMAGE_REGIST = 1;
        public const string IMG_SEL_THUMB = "IMG_THUMB";
        public const string IMG_SEL_REGIST = "IMG_REGIST";
        private string strSelImage = String.Empty;
        private string imgMac = " ";
        private string imgMacSave = " ";


        private void CbxSelImg_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            //switch (CbxSelImg.SelectedIndex)
            //{
            //    case IMAGE_THUMB:
            //        strSelImage = IMG_SEL_THUMB;
            //        break;
            //    case IMAGE_REGIST:
            //        strSelImage = IMG_SEL_REGIST;
            //        break;
            //    default:
            //        strSelImage = IMG_SEL_THUMB;
            //        break;
            //}
        }

#if false
        public const int IMAGE_MACAD = 0;
        public const int IMAGE_DTIME = 1;
        public const string IMG_SEARCH_MACAD = "CHKIMG_MACAD";
        public const string IMG_SEARCH_DTIME = "CHKIMG_DTIME";
        private string strSearchImage = String.Empty;

        private void CbxSearchImg_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            switch (CbxSearchImg.SelectedIndex)
            {
                case IMAGE_MACAD:
                    strSearchImage = IMG_SEARCH_MACAD;
                    break;
                case IMAGE_DTIME:
                    strSearchImage = IMG_SEARCH_DTIME;
                    break;
                default:
                    strSearchImage = IMG_SEARCH_MACAD;
                    break;
            }
        }
#endif
        private void imageSearchMacListInit()
        {
            macAddrCount = 0;
            for( int cnt = 0; cnt<MAX_MACLIST_CNT; cnt++)
            {
                strMacaddress[cnt] = "";
            }
        }

        private void btnClearImage_Click(object sender, RoutedEventArgs e)
        {
            // Mapping初期化
            imageMappingClear();

            // Search用MACカウンタの初期化
            imageSearchMacListInit();

            // Next/Prev ボタン無効
            skipImageButton(false);

            // Search ボタン無効
            //btnSearchImage.IsEnabled = false;

            // 検出画像数表示初期化
            //TImageNo.Content = "";

        }

        private void btnLoadImage_Click(object sender, RoutedEventArgs e)
        {
            // Mapping初期化
            imageMappingClear();

            // Search用MACカウンタの初期化
            imageSearchMacListInit();

            if (LoadImageData(strSelImage) == false)
            {
                return;
            }

            // Next/Prev ボタン有効
            skipImageButton(true);

            // Search ボタン有効
            if (strSelImage == IMG_SEL_THUMB)
            {
                //btnSearchImage.IsEnabled = true;
            }

            //メッセージボックスを表示する
            System.Windows.Forms.MessageBox.Show("Load Completed !!", "Image", MessageBoxButtons.OK, MessageBoxIcon.Information);

            return;

        }

        private void btnImgPrev_Click(object sender, RoutedEventArgs e)
        {
            // Next/Previous ボタン無効
            skipImageButton(false);

            if (startImagePtr > 1)
            {
                if (startImagePtr <= IMAGE_PAGE_LIMIT_DATA)
                {
                    startImagePtr = 1;
                }
                else
                {
                    startImagePtr -= IMAGE_PAGE_LIMIT_DATA;
                }
                if (viewImagePointerGet(startImagePtr) == true)
                {
                    readImagePtr = startImagePtr;
                    //mapImageView(imageDataTable, startImagePtr, endImagePtr);
                    mapImageView(imageSearchDataTable, startImagePtr, endImagePtr);
                }
            }

            // Next/Previous ボタン有効
            skipImageButton(true);
            return;

        }

        private void btnImgNext_Click(object sender, RoutedEventArgs e)
        {
            // Next/Previous ボタン無効
            skipImageButton(false);

            if (endImagePtr < totalImagePtr)
            {
                startImagePtr = endImagePtr++;
                if (viewImagePointerGet(startImagePtr) == true)
                {
                    readImagePtr = startImagePtr;
                    //mapImageView(imageDataTable, startImagePtr, endImagePtr);
                    mapImageView(imageSearchDataTable, startImagePtr, endImagePtr);
                }
            }

            // Next/Previous ボタン有効
            skipImageButton(true);

            return;

        }

        void imageDataTableInit()
        {
            //DataTable初期化
            if (imageDataTable != null)
            {
                DataRow[] rows;
                try
                {
                    rows = imageDataTable.Select();
                    Array.ForEach<DataRow>(rows, row => imageDataTable.Rows.Remove(row));
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine("imageDataTableInit:" + ex.Message);
                }
                rows = null;
            }
        }

        void imageSearchDataTableInit()
        {
            //DataTable初期化
            if (imageSearchDataTable != null)
            {
                DataRow[] rows;
                try
                {
                    rows = imageSearchDataTable.Select();
                    Array.ForEach<DataRow>(rows, row => imageSearchDataTable.Rows.Remove(row));
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine("imageSearchDataTableInit:" + ex.Message);
                }
                rows = null;
            }
        }

        void imageMacDataTableInit()
        {
            //DataTable初期化
            if (imageMacDataTable != null)
            {
                DataRow[] rows;
                try
                {
                    rows = imageMacDataTable.Select();
                    Array.ForEach<DataRow>(rows, row => imageMacDataTable.Rows.Remove(row));
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine("imageMacDataTableInit:" + ex.Message);
                }
                rows = null;
            }
        }

        void pageImageViewInit()
        {
            readImagePtr = 0;
            startImagePtr = 0;
            endImagePtr = 0;
            totalImagePtr = 0;
            //TImageNo.Content = "";
            //ImageNo.Text = "";
            imgMac = "";
            imgMacSave = "";
        }

        void totalImageAdd()
        {
            totalImagePtr++;
            //TImageNo.Content = totalImagePtr.ToString();
        }

        // Page View ボタン制御
        private void skipImageButton(bool status)
        {
            //btnImgNext.IsEnabled = status;
            //btnImgPrev.IsEnabled = status;
        }
        private void nextImageButton(bool status)
        {
            //btnImgNext.IsEnabled = status;
        }
        private void prevImageButton(bool status)
        {
            //btnImgPrev.IsEnabled = status;
        }

        private bool LoadImageData(string sel)
        {
            bool ret = false;
            //string camera_id= " ";
            //string send_time = " ";
            //string thumbnail_file_path = " ";
            string dir= "";

            if (sel == String.Empty)
            {
                // エラー詳細は関数内部でメッセージをだすことにするので
                // ここでは戻るだけ
                return ret;
            }

            //DataTable初期化
            imageDataTableInit();
            imageSearchDataTableInit();
            //Console.WriteLine("LoadImageData:"+"imageDataTableInit");
            imageMacDataTableInit();

            // 初期データ設定
            pageImageViewInit();
            //Console.WriteLine("LoadImageData:" + "pageImageViewInit");

            try
            {
#if true
                if (sel == IMG_SEL_THUMB)
                {
                    dir = THUMB_FILE_PATH;
                }
                else if (sel == IMG_SEL_REGIST)
                {
                    dir = REGIST_FILE_PATH;
                }
                LoadImageDataGet(dir);
#else
                DataRow rowInfo = imageDataTable.NewRow();               
                while (LoadImageDataCheck(sel, ref camera_id, ref send_time, ref thumbnail_file_path) == true)
                {
                    rowInfo["CameraId"] = camera_id;                        // CameraId
                    rowInfo["Date"] = send_time;                            // Date
                    rowInfo["DetFace"] = thumbnail_file_path;               // DetFace
                    imageDataTable.Rows.Add(rowInfo);
                }
#endif
            }
            catch(Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message, "ImageView", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return ret;
            }

            // DataTableコピー
            imageSearchDataTable = imageDataTable.Copy();

            // 検出件数チェック
            //foreach (DataRow drow2 in imageDataTable.Rows)
            foreach (DataRow drow2 in imageSearchDataTable.Rows)
            {
                totalImageAdd();
            }
            readImagePtr++;     // 1～
            startImagePtr = readImagePtr;
            if (viewImagePointerGet(startImagePtr) == false)
            {
                System.Windows.Forms.MessageBox.Show("Image data Nothing !!", "ImageView", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                ret = true;
            }
            //System.Windows.Forms.MessageBox.Show("viewFacePointerGet", "LoadFaceThumbData", MessageBoxButtons.OK, MessageBoxIcon.Information);  // debug 2013.11.29 ishi11
            //mapImageView(imageDataTable, startImagePtr, endImagePtr);
            mapImageView(imageSearchDataTable, startImagePtr, endImagePtr);
            //System.Windows.Forms.MessageBox.Show("mapFaceView", "LoadFaceThumbData", MessageBoxButtons.OK, MessageBoxIcon.Information);  // debug 2013.11.29 ishi11

            //m_image_listView.ItemsSource = ImageMapping;
            //System.Windows.Forms.MessageBox.Show("m_face_listView", "LoadFaceThumbData", MessageBoxButtons.OK, MessageBoxIcon.Information);  // debug 2013.11.29 ishi11

            return ret;
        }

        private void imgMacAddressSet(string macad)
        {
        //public int macAddrCount = 0;
        //public const int MAX_MACLIST_CNT = 20;
        //public string []strMacaddress = new string[MAX_MACLIST_CNT]{"","","","","","","","","","",
            if (macAddrCount < 20)
            {
                strMacaddress[macAddrCount] = macad;
                macAddrCount++;

                // DataTableへの加算
                DataRow rowInfo = imageMacDataTable.NewRow();
                rowInfo["MacCount"] = macAddrCount; 
                rowInfo["MacStr"] = macad;           
                imageMacDataTable.Rows.Add(rowInfo);
            }
        }

        private void LoadImageDataGet(string dir)
        {
            string imgDirName;
            string imgFileName;
            string imgDate = "";
            string imgDateYear = "";
            string imgDateMonth = "";
            string imgDateDate = "";
            string imgDateHour = "";
            Int32 imgDateCheck = 0;

            string[] files = Directory.GetFiles(dir);
            foreach (string imgFilePath in files)
            {
                //Console.WriteLine(s);
                DataRow rowInfo = imageDataTable.NewRow();
                imgDirName = Path.GetDirectoryName(imgFilePath);
                imgFileName = Path.GetFileName(imgFilePath);
                if (strSelImage == IMG_SEL_THUMB)
                {
                    // Thumbnail path/file
                    //  C:\\ASF900\\img\\thumbnail\\(MAC8桁)\\(MAC2桁)\\(MAC2桁)\\(年)\\(月)\\(日)\\(時)
                    //
                    imgDateYear = imgFileName.Substring(IMG_YEAR_POS, IMG_YEAR_LEN);
                    imgDateMonth = imgFileName.Substring(IMG_MONTH_POS, IMG_MONTH_LEN);
                    imgDateDate = imgFileName.Substring(IMG_DATE_POS, IMG_DATE_LEN);
                    imgDateHour = imgFileName.Substring(IMG_HOUR_POS, IMG_HOUR_LEN);
                    if((selDateStatus != -1) && (selDateStatus != 0))
                    {   // 日付指定された時
                        imgDateCheck = Convert.ToInt32(imgDateYear + imgDateMonth + imgDateDate + imgDateHour);
                        if ((imgDateCheck < selectFromDate) || (imgDateCheck > selectToDate))
                        {
                            break;
                        }
                    }

                    //imgMac = imgDirName.Substring(24, 8);
                    //imgMac += imgDirName.Substring(33, 2);
                    //imgMac += imgDirName.Substring(36, 2);
                    //imgDate = Path.GetFileName(imgFilePath).Substring(0, 14);
                    imgMac = imgDirName.Substring(IMG_MAC1_POS, IMG_MAC1_LEN);
                    imgMac += imgDirName.Substring(IMG_MAC2_POS, IMG_MAC2_LEN);
                    imgMac += imgDirName.Substring(IMG_MAC3_POS, IMG_MAC3_LEN);
                    if (imgMac != imgMacSave)
                    {
                        // MACアドレスの格納
                        imgMacAddressSet(imgMac);
                        imgMacSave = imgMac;
                    }
                    rowInfo["MacAddress"] = imgMac;                                         // Camera MAC
                    //imgDateYear = imgFileName.Substring(IMG_YEAR_POS, IMG_YEAR_LEN);
                    //imgDateMonth = imgFileName.Substring(IMG_MONTH_POS, IMG_MONTH_LEN);
                    //imgDateDate = imgFileName.Substring(IMG_DATE_POS, IMG_DATE_LEN);
                    //imgDateHour = imgFileName.Substring(IMG_HOUR_POS, IMG_HOUR_LEN);
                    imgDate = imgDateYear + "/";
                    imgDate += imgDateMonth + "/";
                    imgDate += imgDateDate + " ";
                    imgDate += imgDateHour + ":";
                    imgDate += imgFileName.Substring(IMG_MIN_POS, IMG_MIN_LEN) + ":";
                    imgDate += imgFileName.Substring(IMG_SEC_POS, IMG_SEC_LEN);
                    //rowInfo["ImageDate"] = DateTimeUtil.ConvUTCToLocalDateTime(imgDate).ToString();
                    //                                                                     // Date
                    rowInfo["ImageDate"] = imgDate;                                        // Date(UTC)
                }
                else
                {
                    //
                    rowInfo["MacAddress"] = imgMac;                                         // Camera MAC
                    rowInfo["ImageDate"] = imgDate;                                         // Date
                }
                rowInfo["ImageFace"] = imgFilePath;                                         // DetFace
                imageDataTable.Rows.Add(rowInfo);
            }

            string[] dirs = Directory.GetDirectories(dir);
            foreach (string s in dirs)
            {
                LoadImageDataGet(s);
            }
        }

#if false	         
        private bool LoadImageDataCheck(string sel,ref string camera_id, ref string send_time, ref string thumbnail_file_path )
        {
            bool status = false;

            switch (sel)
            {
                case IMG_SEL_THUMB:
                    if (LoadImageThumbData(ref camera_id, ref send_time, ref thumbnail_file_path) == true)
                    {
                        status = true;
                    }
                    break;
                case IMG_SEL_REGIST:
                    if (LoadImageRegistData(ref camera_id, ref send_time, ref thumbnail_file_path) == true)
                    {
                        status = true;
                    }
                    break;
                default:
                    break;
            }
            return status;
        }

        private bool LoadImageThumbData(ref string camera_id, ref string dtime, ref string thumbnail_file_path)
        {
            // Thumbnail path/file
            //  C:\ASF900\img\thumbnail\(MAC8桁)\(MAC2桁)\(MAC2桁)\(年)\(月)\(日)\(時)\(ファイル名)

            // 初期化
            bool retsts = false;
            camera_id = " ";
            dtime = " ";
            thumbnail_file_path = " ";

            // step1
            // Passのチェック
            DoIt(THUMB_FILE_PATH);


            // step2
            // 
            return retsts;
        }

        private bool LoadImageRegistData(ref string camera_id, ref string dtime, ref string thumbnail_file_path)
        {
            // Regist path/file
            //  C:\ASF900\img\alarm\(年)\(月)\(日)\(時)\(ファイル名)

            // 初期化
            bool retsts = false;
            camera_id = " ";
            dtime = " ";
            thumbnail_file_path = " ";

            // step1
            // Passのチェック

            return retsts;
        }
#endif

        private void imageMappingClear()
        {
            Console.WriteLine(" ----- Load Data(Image) View -----");

            m_image_mapping.Clear();                                 // マッピング初期化

            // ガベージコレクション
            GC.Collect();

            //m_image_listView.ItemsSource = ImageMapping;              // マッピングアイテムの表示
        }

        private void mapImageView(DataTable dt, Int32 readStart, Int32 readEnd)
        {

            // マッピングアイテムに設定する
            string mac_ad;
            string tmp_time;
            string set_time;
            string thumbnail_file_path;
            string imgFileName;
            Int32 sttcnt = readStart - 1;
            Int32 endcnt = readEnd - 1;

            // ---<< Exportされたデータの表示>>---
            m_image_mapping.Clear();                                 // マッピング初期化

            // ガベージコレクション
            GC.Collect();

            // 行数分のマッピングアイテム設定を実施
            Int32 cnt;
            DataRow draw;
            for (cnt = sttcnt; cnt < endcnt; cnt++)
            {
                draw = dt.Rows[cnt];
                mac_ad = (string)draw["MacAddress"];
                //set_time = (string)draw["ImageDate"];
                tmp_time = (string)draw["ImageDate"];
                if (strSelImage == IMG_SEL_THUMB)
                {
                    set_time = DateTimeUtil.ConvUTCToLocalDateTime(tmp_time).ToString();
                }
                else
                {
                    set_time = tmp_time;
                }
                thumbnail_file_path = (String)draw["ImageFace"];
                imgFileName = Path.GetFileName(thumbnail_file_path);
                // マッピングアイテムの設定(１行)
                //ImageMappingItem item = new ImageMappingItem((cnt + 1), thumbnail_file_path, mac_ad, set_time);
                //ImageMappingItem item = new ImageMappingItem((cnt + 1), thumbnail_file_path, thumbnail_file_path, set_time);
                ImageMappingItem item = new ImageMappingItem((cnt + 1), mac_ad, set_time, thumbnail_file_path, imgFileName);
                //ImageMappingItem item = new ImageMappingItem((cnt + 1), mac_ad, thumbnail_file_path, imgFileName);
                m_image_mapping.Add(item);
            }

            // マッピングアイテムの表示
            //m_image_listView.ItemsSource = ImageMapping;
        }

        bool viewImagePointerGet(Int32 ptr)
        {
            bool ret = false;
            if (ptr > totalImagePtr)
            {   // Warning
            }
            else
            {
                endImagePtr = ptr + IMAGE_PAGE_LIMIT_DATA;
                if (endImagePtr > totalImagePtr)
                {
                    endImagePtr = totalImagePtr + 1;
                }
                ret = true;
            }
            return ret;
        }

        private void ImageNo_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            // データ入力中に＜Enter＞がきたら 画面表示させる
            if (e.Key == Key.Return)
            {
                // Input data check
                //if (ImageNo.Text == "")
                //{
                //    return;
                //}

                // Next/Previous ボタン無効
                skipImageButton(false);

                //Int32 ptr = Convert.ToInt32(ImageNo.Text);
                //if (ptr == 0) { ptr++; }
                //if (viewImagePointerGet(ptr) == true)
                //{
                //    startImagePtr = ptr;
                //    readImagePtr = ptr;
                    //mapImageView(imageDataTable, startImagePtr, endImagePtr);
                //    mapImageView(imageSearchDataTable, startImagePtr, endImagePtr);
                //}

                // Next/Previous ボタン有効
                skipImageButton(true);
            }

        }

        private void btnDateImage_Click(object sender, RoutedEventArgs e)
        {
            if (strSelImage == IMG_SEL_REGIST)
            {   // Alarm登録は日付指定なし
                return;
            }

            //btnDateImage.Content = "Date";
            ImageDate imageDateKey = new ImageDate();
            imageDateKey.Owner = this;
            imageDateKey.ShowDialog();

            // 検索条件をImageDateクラスより取り出してテーブルの再構築
            int selsts = ImageDate.selStatus;
            selDateStatus = selsts;
            if ((selsts != -1)&&(selsts!=0))
            {
                //btnDateImage.Content = ImageDate.strSelDate;
                // LocalからUTCに変換
                DateTime fromDt = DateTimeUtil.ConvLocalToUTCDateTime(ImageDate.strSelDate + " 00:00:00");
                DateTime toDt = DateTimeUtil.ConvLocalToUTCDateTime(ImageDate.strSelDate + " 23:59:59");
                string strFromDt = fromDt.ToString();
                string s = strFromDt.Substring(0,4) + strFromDt.Substring(5,2) + strFromDt.Substring(8,2) + strFromDt.Substring(11,2);
                selectFromDate = Convert.ToInt32(s);
                string strToDt = toDt.ToString();
                s = strToDt.Substring(0, 4) + strToDt.Substring(5, 2) + strToDt.Substring(8, 2) + strToDt.Substring(11, 2);
                selectToDate = Convert.ToInt32(s);
            }
        }

        private void btnSearchImage_Click(object sender, RoutedEventArgs e)
        {
            //ImageSearch imageSearchKey = new ImageSearch(imageDataTable, imageSearchDataTable, imageMacDataTable);
            ImageSearch imageSearchKey = new ImageSearch(imageMacDataTable);
            imageSearchKey.Owner = this;
            imageSearchKey.ShowDialog();

            // 検索条件をImageSearchクラスより取り出してテーブルの再構築
            int selsts = ImageSearch.selStatus;

            if (selsts != -1)
            {
                // データ抽出条件
                bool bMac=false;
                bool bFrom=false;
                bool bTo=false;
                string macaddr = String.Empty;
                string fromDate = String.Empty;
                string toDate = String.Empty;
                // データ抽出パラメータ
                string expMac = String.Empty;
                string expFrom = String.Empty;
                string expTo = String.Empty;
                string expression = String.Empty;
                string sort = "ImageDate DESC";                 // ソート条件(降順)

                imageSearchDataTableInit();                     // imageSearchDataTableを空にする

                // 抽出パラメータの獲得
                if (ImageSearch.strMacAd != "ALL")
                {
                    macaddr = ImageSearch.strMacAd;
                }
                if (ImageSearch.strFrom != String.Empty)
                {
                    fromDate = DateTimeUtil.ConvLocalToUTCDateTime(ImageSearch.strFrom).ToString();
                }
                if (ImageSearch.strTo != String.Empty)
                {
                    toDate = DateTimeUtil.ConvLocalToUTCDateTime(ImageSearch.strTo).ToString();
                }
                
                if (macaddr != String.Empty)
                {
                    bMac = true;
                    expMac = "MacAddress ='" + macaddr + "'";
                    //sort = "MacAddress '" + macaddr + "'";                    }
                }
                if (fromDate != String.Empty)
                {
                    bFrom = true;
                    //expFrom = "ImageDate >= '" + fromDate + "'";
                    expFrom = "ImageDate >= #" + fromDate + "#";
                }
                if (toDate != String.Empty)
                {
                    bTo = true;
                    //expTo = "ImageDate <= '" + toDate + "'";
                    expTo = "ImageDate <= #" + toDate + "#";
                }

                if (bMac==true)
                {   // MAC指定
                    if (bFrom == true) 
                    {
                        if(bTo==true)
                        {   // MAC/From/Toで抽出
                            expression = expMac + " and " + expFrom + " and " + expTo;
                        }
                        else
                        {   // MAC/Fromで抽出
                            expression = expMac + " and " + expFrom;
                        }
                    }
                    else
                    {
                        if(bTo==true)
                        {   // MAC/Toで抽出
                            expression = expMac + " and " + expTo;
                        }
                        else
                        {   // MACのみで抽出
                            expression = expMac;
                        }
                    }
                }
                else
                {   // すべてのMAC
                     if (bFrom == true) 
                    {
                        if(bTo==true)
                        {   // From/Toで抽出
                            expression = expFrom + " and " + expTo;
                        }
                        else
                        {   // Fromで抽出
                            expression = expFrom;
                        }
                    }
                    else
                    {
                        if(bTo==true)
                        {   // Toで抽出
                            expression = expTo;
                        }
                        else
                        {   // なし...ソートのみ
                            expression = String.Empty;
                        }
                    }                   
                }
                 
                // for Check
                //DataRow drow;
                //string checkmac;
                //for (Int16 cnt=0; cnt < 8; cnt++)
                //{
                //    drow = imageDataTable.Rows[cnt];
                //    checkmac = (String)drow["MacAddress"];
                //    Console.WriteLine(checkmac);
                //}

                //DataRow[] rows = imageDataTable.Select(expression, null);
                DataRow[] rows = imageDataTable.Select(expression, sort);
                foreach (DataRow row in rows)
                {
                    DataRow rowInfo = imageSearchDataTable.NewRow();

                    // カラム情報をコピーします。
                    rowInfo.ItemArray = row.ItemArray;

                    // DataTableに格納します。
                    imageSearchDataTable.Rows.Add(rowInfo);

                }
            }

            // 初期データ設定
            pageImageViewInit();                                // pointerの初期化

            // 検出件数チェック
            foreach (DataRow drow2 in imageSearchDataTable.Rows)
            {
                totalImageAdd();
            }
            readImagePtr++;     // 1～
            startImagePtr = readImagePtr;
            if (viewImagePointerGet(startImagePtr) == false)
            {
                imageMappingClear();
                System.Windows.Forms.MessageBox.Show("Search data Nothing !!", "ImageView", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                mapImageView(imageSearchDataTable, startImagePtr, endImagePtr);
                //m_image_listView.ItemsSource = ImageMapping;
            }
        }

    }

}
