﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Windows.Forms;

namespace FaceMatchDBTool
{
    /// <summary>
    /// ImageSearch.xaml の相互作用ロジック
    /// </summary>
    public partial class ImageSearch : Window
    {
        //string[] stMacAddress = new string[]{"aaa","bbb","ccc","ddd","eee","fff","ggg","hhh","iii","jjj",
        //                                    "kkk","lll","mmm","nnn","ooo","ppp","qqq","rrr","sss","ttt"};
        string[] stMacAddress = new string[20];

        // プロパティ
        private static int _selStatus;
        public static int selStatus
        {
            get
            {
                return _selStatus;
            }
        }
        private static string _strMacAd;
        public static string strMacAd
        {
            get
            {
                return _strMacAd;
            }
        }
        private static string _strFrom;
        public static string strFrom
        {
            get
            {
                return _strFrom;
            }
        }
        private static string _strTo;
        public static string strTo
        {
            get
            {
                return _strTo;
            }
        }

        // ウインドウメイン処理
        //public ImageSearch(DataTable alldt, DataTable sdt, DataTable macdt)
        public ImageSearch(DataTable macdt)
        {
            InitializeComponent();

            ImageSearchListInit();
            ImageSearchListSet(macdt);

            _selStatus = -1;
        }

        private void btnImgSearchOK_Click(object sender, RoutedEventArgs e)
        {
            int macCount = CbxMACSel.SelectedIndex;
            string macAdd = String.Empty;
            string sql = String.Empty;
            int retsts = 0;
            string fromDT = String.Empty;
            string toDT = String.Empty;

            // MACアドレスの獲得
            if ((macCount != 0) && (macCount != -1))
            {   // Select
                macAdd = stMacAddress[macCount - 1];
            }
            _strMacAd = macAdd;

            // 時間範囲の獲得
            retsts = CheckRangeData(ref fromDT, ref toDT);
            if (retsts == -1)
            {
                return;
            }
            _selStatus = retsts;
            _strFrom = fromDT;
            _strTo = toDT;

            // ウインドウのクローズ
            this.Close();
        }

        private void btnImgSearchCan_Click(object sender, RoutedEventArgs e)
        {
            _selStatus = -1;
            _strFrom = "";
            _strTo = "";
            _strMacAd = "";

            // ウインドウのクローズ
            this.Close();
        }

        private void CbxMACSel_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            // 無処理
        }

        public void ImageSearchListInit()
        {
            CbxMACSel.Items.Clear();
            CbxMACSel.Items.Add("ALL");
        }

        public void ImageSearchListSet(DataTable macdt)
        {
            int cnt = 0;

            foreach (DataRow dr in macdt.Rows)
            {
                string mac_ad;

                mac_ad = (String)dr["MacStr"];
                CbxMACSel.Items.Add(mac_ad);
                stMacAddress[cnt] = mac_ad;
                cnt++;
            }
        }

        private int CheckRangeData(ref string fromDate, ref string toDate)
        {
            int whereFlag = 0;

            if (TxtImgSearchFrom.Text.Length > 0)
            {
                if (System.Text.RegularExpressions.Regex.IsMatch(TxtImgSearchFrom.Text, @"^\d{4}/\d{2}/\d{2} \d{2}:\d{2}$",
                        System.Text.RegularExpressions.RegexOptions.ECMAScript))
                {
                    try
                    {
                        DateTime dt = DateTime.Parse(TxtImgSearchFrom.Text + ":00");       // 時刻変換チェック
                        fromDate = TxtImgSearchFrom.Text + ":00";
                    }
                    catch
                    {
                        //メッセージボックスを表示する
                        System.Windows.Forms.MessageBox.Show("'From' is invalid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return -1;
                    }
                    whereFlag |= 1;
                }
                else
                {
                    //メッセージボックスを表示する
                    System.Windows.Forms.MessageBox.Show("'From' is invalid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                }
            }

            if (TxtImgSearchTo.Text.Length > 0)
            {
                if (System.Text.RegularExpressions.Regex.IsMatch(TxtImgSearchTo.Text, @"^\d{4}/\d{2}/\d{2} \d{2}:\d{2}$",
                         System.Text.RegularExpressions.RegexOptions.ECMAScript))
                {
                    try
                    {
                        DateTime dt = DateTime.Parse(TxtImgSearchTo.Text + ":00");       // 時刻変換チェック
                        toDate = TxtImgSearchTo.Text + ":00";
                    }
                    catch
                    {
                        //メッセージボックスを表示する
                        System.Windows.Forms.MessageBox.Show("'To' is invalid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return -1;
                    }
                    whereFlag |= 2;
                }
                else
                {
                    //メッセージボックスを表示する
                    System.Windows.Forms.MessageBox.Show("'To' is invalid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return -1;
                }
            }
            return whereFlag;
        }

    }
}
