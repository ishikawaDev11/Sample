﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace FaceMatchDBTool
{
    class ImageMappingItem : DependencyObject
    {
        private static readonly DependencyPropertyKey ImgNoPropertyKey = DependencyProperty.RegisterReadOnly("ImgNo", typeof(string), typeof(ImageMappingItem), new PropertyMetadata());
        private static readonly DependencyPropertyKey MacAddressPropertyKey = DependencyProperty.RegisterReadOnly("MacAddress", typeof(string), typeof(ImageMappingItem), new PropertyMetadata());
        private static readonly DependencyPropertyKey ImgDatePropertyKey = DependencyProperty.RegisterReadOnly("ImgDate", typeof(string), typeof(ImageMappingItem), new PropertyMetadata());
        private static readonly DependencyPropertyKey ThumbnailPropertyKey = DependencyProperty.RegisterReadOnly("Thumbnail", typeof(ImageSource), typeof(ImageMappingItem), new PropertyMetadata(null));
        private static readonly DependencyPropertyKey ImgFileNamePropertyKey = DependencyProperty.RegisterReadOnly("ImageFileName", typeof(string), typeof(ImageMappingItem), new PropertyMetadata());

        public string ImgNo
        {
            get
            {
                return (string)base.GetValue(ImageMappingItem.ImgNoPropertyKey.DependencyProperty);
            }
            private set
            {
                base.SetValue(ImageMappingItem.ImgNoPropertyKey, value);
            }
        }

        public string MacAddress
        {
            get
            {
                return (string)base.GetValue(ImageMappingItem.MacAddressPropertyKey.DependencyProperty);
            }
            private set
            {
                base.SetValue(ImageMappingItem.MacAddressPropertyKey, value);
            }
        }

        public ImageSource Thumbnail
        {
            get
            {
                return (ImageSource)base.GetValue(ImageMappingItem.ThumbnailPropertyKey.DependencyProperty);
            }
            private set
            {
                base.SetValue(ImageMappingItem.ThumbnailPropertyKey, value);
            }
        }

        public string ImgDate
        {
            get
            {
                return (string)base.GetValue(ImageMappingItem.ImgDatePropertyKey.DependencyProperty);
            }
            private set
            {
                base.SetValue(ImageMappingItem.ImgDatePropertyKey, value);
            }
        }

        public string ImgFileName
        {
            get
            {
                return (string)base.GetValue(ImageMappingItem.ImgFileNamePropertyKey.DependencyProperty);
            }
            private set
            {
                base.SetValue(ImageMappingItem.ImgFileNamePropertyKey, value);
            }
        }

        //コンストラクタ
        public ImageMappingItem(long imgNo, string macAddress, string imgDate, string filePath, string imgFileName)
        {
            if (File.Exists(filePath))
            {
                MemoryStream data = new MemoryStream(File.ReadAllBytes(filePath)); WriteableBitmap wbmp = new WriteableBitmap(BitmapFrame.Create(data)); data.Close();
                this.Thumbnail = wbmp;
            }
            else
            {
                this.Thumbnail = new System.Windows.Media.Imaging.BitmapImage();
            }

            this.ImgNo = String.Format("{0:D6}", imgNo);
            this.MacAddress = macAddress;
            this.ImgDate = imgDate;
            this.ImgFileName = imgFileName;
        }
    }
}

