﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace FaceMatchDBTool
{
    class MappingItem : DependencyObject
    {
        private static readonly DependencyPropertyKey ThumbnailPropertyKey = DependencyProperty.RegisterReadOnly("Thumbnail", typeof(ImageSource), typeof(MappingItem), new PropertyMetadata(null));
        private static readonly DependencyPropertyKey CameraNoPropertyKey = DependencyProperty.RegisterReadOnly("CameraNo", typeof(string), typeof(MappingItem), new PropertyMetadata());
        private static readonly DependencyPropertyKey ShotDatePropertyKey = DependencyProperty.RegisterReadOnly("ShotDate", typeof(string), typeof(MappingItem), new PropertyMetadata());
        private static readonly DependencyPropertyKey DetectIdPropertyKey = DependencyProperty.RegisterReadOnly("DetectId", typeof(string), typeof(MappingItem), new PropertyMetadata());
        private static readonly DependencyPropertyKey ScorePropertyKey = DependencyProperty.RegisterReadOnly("Score", typeof(string), typeof(MappingItem), new PropertyMetadata()); // 2013.11.14 ishi11
        private static readonly DependencyPropertyKey Thumbnail2PropertyKey = DependencyProperty.RegisterReadOnly("Thumbnail2", typeof(ImageSource), typeof(MappingItem), new PropertyMetadata(null));
        private static readonly DependencyPropertyKey AlarmNoPropertyKey = DependencyProperty.RegisterReadOnly("AlarmNo", typeof(string), typeof(MappingItem), new PropertyMetadata()); // 2013.11.18 ishi11

        public ImageSource Thumbnail
        {
            get
            {
                return (ImageSource)base.GetValue(MappingItem.ThumbnailPropertyKey.DependencyProperty);
            }
            private set
            {
                base.SetValue(MappingItem.ThumbnailPropertyKey, value);
            }
        }

        public string CameraNo
        {
            get
            {
                return (string)base.GetValue(MappingItem.CameraNoPropertyKey.DependencyProperty);
            }
            private set
            {
                base.SetValue(MappingItem.CameraNoPropertyKey, value);
            }
        }

        public string ShotDate
        {
            get
            {
                return (string)base.GetValue(MappingItem.ShotDatePropertyKey.DependencyProperty);
            }
            private set
            {
                base.SetValue(MappingItem.ShotDatePropertyKey, value);
            }
        }

        public string DetectId
        {
            get
            {
                return (string)base.GetValue(MappingItem.DetectIdPropertyKey.DependencyProperty);
            }
            private set
            {
                base.SetValue(MappingItem.DetectIdPropertyKey, value);
            }
        }

        public string Score                 // 2013.11.14 ishi11
        {
            get
            {
                return (string)base.GetValue(MappingItem.ScorePropertyKey.DependencyProperty);
            }
            private set
            {
                base.SetValue(MappingItem.ScorePropertyKey, value);
            }
        }

        public ImageSource Thumbnail2       // 2013.11.14 ishi11
        {
            get
            {
                return (ImageSource)base.GetValue(MappingItem.Thumbnail2PropertyKey.DependencyProperty);
            }
            private set
            {
                base.SetValue(MappingItem.Thumbnail2PropertyKey, value);
            }
        }

        public string AlarmNo
        {
            get
            {
                return (string)base.GetValue(MappingItem.AlarmNoPropertyKey.DependencyProperty);
            }
            private set
            {
                base.SetValue(MappingItem.AlarmNoPropertyKey, value);
            }
        }


        //コンストラクタ
        //public MappingItem(string filePath, long cameraNo, string shotDate, string detectId)
        //public MappingItem(string filePath, long cameraNo, string shotDate, string detectId, string score, string filePath2)    // 2013.11.14 ishi11
        public MappingItem(long no, string filePath, long cameraNo, string shotDate, string detectId, string score, string filePath2)    // 2013.11.14 ishi11
        {
            if (File.Exists(filePath))
            {
#if true        // Test 2013.11.15 ishi11
                MemoryStream data = new MemoryStream(File.ReadAllBytes(filePath)); WriteableBitmap wbmp = new WriteableBitmap(BitmapFrame.Create(data)); data.Close();
                this.Thumbnail = wbmp;
#else
                this.Thumbnail = new System.Windows.Media.Imaging.BitmapImage(new Uri(filePath, UriKind.Absolute));
#endif
            }
            else
            {
                this.Thumbnail = new System.Windows.Media.Imaging.BitmapImage();
            }

            this.CameraNo = cameraNo.ToString();
            this.ShotDate = shotDate;
            this.DetectId = detectId;
            this.Score = score;                                                                                                 // 2013.11.14 ishi11

            if (File.Exists(filePath2))                                                                                         // 2013.11.14 ishi11
            {                                                                                                                   // 2013.11.14 ishi11
#if true        // Test 2013.11.15 ishi11
                MemoryStream data = new MemoryStream(File.ReadAllBytes(filePath2)); WriteableBitmap wbmp = new WriteableBitmap(BitmapFrame.Create(data)); data.Close();
                this.Thumbnail2 = wbmp;
#else
                this.Thumbnail2 = new System.Windows.Media.Imaging.BitmapImage(new Uri(filePath2, UriKind.Absolute));           // 2013.11.14 ishi11
#endif
            }                                                                                                                   // 2013.11.14 ishi11
            else
            {
                this.Thumbnail2 = new System.Windows.Media.Imaging.BitmapImage();
            }

            this.AlarmNo = String.Format("{0:D6}", no);                                                                         // 2013.11.18 ishi11

        }
    }
}
