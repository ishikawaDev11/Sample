﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FaceMatchDBTool
{
    /// <summary>
    /// 日付時刻編集 ユーティリティ
    /// </summary>
    public class DateTimeUtil
    {
        /// <summary>
        /// UTC形式の日付時刻文字列(yyyy-MM-ddTHH:mm:ss.fff)を
        /// UTC形式のDateTime型で返します
        /// </summary>
        /// <param name="s_shot_date">yyyy-MM-ddTHH:mm:ss.fff形式のUTC時刻文字列</param>
        /// <returns>UTC形式のDateTime型</returns>
        #region UTCDateTime
        public static DateTime UTCDateTime(string s_shot_date)
        {
            DateTime utc_input;
            utc_input = new DateTime();
            if (!String.IsNullOrEmpty(s_shot_date))
            {
                utc_input = System.DateTime.ParseExact(
                                            s_shot_date,
                                            "yyyy-MM-ddTHH:mm:ss.fff",
                                            System.Globalization.DateTimeFormatInfo.InvariantInfo,
                                            System.Globalization.DateTimeStyles.NoCurrentDateDefault);
            }

            return utc_input;
        }
        #endregion

        /// <summary>
        /// UTC形式の日付時刻文字列(yyyy-MM-ddTHH:mm:ss.fff)を
        /// ローカル時刻に変換し、DateTime型の日付を返します
        /// </summary>
        /// <param name="s_shot_date">yyyy-MM-ddTHH:mm:ss.fff形式のUTC時刻文字列</param>
        /// <returns>ローカル時刻に変換したDateTime型の日付</returns>
        #region LocalDateTime
        public static DateTime LocalDateTime(string s_shot_date)
        {
            DateTime local_input;
            local_input = new DateTime();
            if (!String.IsNullOrEmpty(s_shot_date))
            {
                TimeZoneInfo tzi = TimeZoneInfo.Local;
                local_input = TimeZoneInfo.ConvertTimeFromUtc(UTCDateTime(s_shot_date), tzi);
            }

            return local_input;
        }
        #endregion

        /// <summary>
        /// ローカル形式の日付時刻文字列(yyyy-MM-ddTHH:mm:ss.fff)を
        /// UTC時刻に変換し、DateTime型の日付を返します
        /// </summary>
        /// <param name="s_shot_date">yyyy-MM-ddTHH:mm:ss.fff形式のローカル時刻文字列</param>
        /// <returns>UTC時刻に変換したDateTime型の日付</returns>
        #region LocalToUTCDateTime
        public static DateTime LocalToUTCDateTime(string s_shot_date)
        {
            DateTime utc_input;
            DateTime local_input = new DateTime();
            utc_input = new DateTime();
            if (!String.IsNullOrEmpty(s_shot_date))
            {
                local_input = System.DateTime.ParseExact(
                                                s_shot_date,
                                                "yyyy-MM-ddTHH:mm:ss.fff",
                                                System.Globalization.DateTimeFormatInfo.InvariantInfo,
                                                System.Globalization.DateTimeStyles.NoCurrentDateDefault);

                //TimeZoneInfo tzi = System.TimeZoneInfo.FindSystemTimeZoneById("Tokyo Standard Time");
                TimeZoneInfo tzi = System.TimeZoneInfo.Local;
                utc_input = TimeZoneInfo.ConvertTimeToUtc(local_input, tzi);
            }

            return utc_input;
        }
        #endregion

        /// <summary>
        /// ローカル形式の日付時刻文字列(yyyy/MM/dd HH:mm:ss)を
        /// UTC時刻に変換し、DateTime型の日付を返します
        /// </summary>
        /// <param name="s_shot_date">yyyy/MM/dd HH:mm:ss形式のローカル時刻文字列</param>
        /// <returns>UTC時刻に変換したDateTime型の日付</returns>
        #region ConvLocalToUTCDateTime
        public static DateTime ConvLocalToUTCDateTime(string s_shot_date)
        {
            DateTime utc_input;
            DateTime local_input = new DateTime();
            utc_input = new DateTime();
            if (!String.IsNullOrEmpty(s_shot_date))
            {
                //DateTime dt = DateTime.Parse(s_shot_date);
                //s_shot_date = dt.ToString("yyyy-MM-ddTHH:mm:ss.fff");
                local_input = System.DateTime.ParseExact(
                                                s_shot_date,
                                                "yyyy/MM/dd HH:mm:ss",
                                                System.Globalization.DateTimeFormatInfo.InvariantInfo,
                                                System.Globalization.DateTimeStyles.NoCurrentDateDefault);

                //TimeZoneInfo tzi = System.TimeZoneInfo.FindSystemTimeZoneById("Tokyo Standard Time");
                TimeZoneInfo tzi = System.TimeZoneInfo.Local;
                utc_input = TimeZoneInfo.ConvertTimeToUtc(local_input, tzi);
            }

            return utc_input;
        }
        #endregion

        /// <summary>
        /// UTC形式の日付時刻文字列(yyyy/MM/dd HH:mm:ss)を
        /// ローカル時刻に変換し、DateTime型の日付を返します
        /// </summary>
        /// <param name="s_shot_date">yyyy/MM/dd HH:mm:ss形式のUTC時刻文字列</param>
        /// <returns>ローカル時刻に変換したDateTime型の日付</returns>
        #region ConvUTCToLocalDateTime
        public static DateTime ConvUTCToLocalDateTime(string s_shot_date)
        {
            DateTime local_input = new DateTime();
            DateTime dt = DateTime.Parse(s_shot_date);
            s_shot_date = dt.ToString("yyyy-MM-ddTHH:mm:ss.fff");
            if (!String.IsNullOrEmpty(s_shot_date))
            {
                TimeZoneInfo tzi = TimeZoneInfo.Local;
                local_input = TimeZoneInfo.ConvertTimeFromUtc(UTCDateTime(s_shot_date), tzi);
            }

            return local_input;
        }

        public static DateTime ConvUTCToLocalDateTime(DateTime dt)
        {
            DateTime local_input = new DateTime();
            //DateTime dt = DateTime.Parse(s_shot_date);
            string s_shot_date = dt.ToString("yyyy-MM-ddTHH:mm:ss.fff");
            if (!String.IsNullOrEmpty(s_shot_date))
            {
                TimeZoneInfo tzi = TimeZoneInfo.Local;
                local_input = TimeZoneInfo.ConvertTimeFromUtc(UTCDateTime(s_shot_date), tzi);
            }

            return local_input;
        }

        #endregion
    }
}
