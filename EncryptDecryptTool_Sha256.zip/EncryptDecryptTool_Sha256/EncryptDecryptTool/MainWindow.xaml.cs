﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Security.Cryptography;



namespace EncryptDecryptTool
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {
        private const String KEY = "9f36f7ac2fcb88d531df892376c3e304"; // 32byte = 256bit"
        private const int HASH_SHA256 = 1;      // cbxHashのitem番号
        private const int HASH_MD5 = 0;         // cbxHashのitem番号

        //private ClassCrypt Crypt;
        private bool initWindow;
        private ClassCrypt cc;

        public MainWindow()
        {
            initWindow = false;
            InitializeComponent();
            initView();
            cc = new ClassCrypt();
            initWindow = true;

        }

        #region ボタンクリック
        private void btnMakeKey_Click(object sender, RoutedEventArgs e)
        {
            // 暗号化キーの暗号化用キー取得
            byte[] bufferKey = Encoding.UTF8.GetBytes(KEY);

            // 暗号化キーの作成
            // (1)平文をハッシュ化して暗号化キーを作成
            // (2)暗号化キーを暗号化してRDB格納用のキーを作成する
            byte[] hash256Value = new byte[32];
            #region SHA256
            if (cbxHash.SelectedIndex == HASH_SHA256)
            {
                byte[] sourcebyte = System.Text.Encoding.GetEncoding("UTF-8").GetBytes(txtKey.Text);
                // SHA256のハッシュ値を計算する
                SHA256 crypt256 = new SHA256CryptoServiceProvider();
                hash256Value = crypt256.ComputeHash(sourcebyte);

                // SHA256の計算結果をUTF8で文字列として取り出す
                StringBuilder hashedText = new StringBuilder();
                for (int i = 0; i < hash256Value.Length; i++)
                {
                    // 16進の数値を文字列として取り出す
                    hashedText.AppendFormat("{0:x2}", hash256Value[i]);
                }
                string hash256String = hashedText.ToString();
                txtHashKey.Text = hashedText.ToString();

                string outBuf = string.Empty;
                if (cc.EncryptionSha256(bufferKey, hash256String, out outBuf) == 0)
                {
                    txtRdbKey.Text = outBuf;
                    if (check_encrypt_data(KEY, txtRdbKey.Text) == false)
                    {
                        MessageBox.Show("暗号化データがおかしい？");
                    }
                }
                else
                {   // Error
                    txtRdbKey.Text = "暗号化に失敗しました";
                }
            }
            #endregion  // SHA256
            else
            #region MD5
            {
                byte[] sourcebyte = System.Text.Encoding.GetEncoding("UTF-8").GetBytes(txtKey.Text);
                MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
                byte[] md5byte = md5.ComputeHash(sourcebyte);
                string data = BytesConvert.ToHexString(md5byte);
                txtHashKey.Text = data;
                
                //StringBuilder result = new StringBuilder();
                //for (int i = 0; i < md5byte.Length; i++)
                //{
                //    result.Append(md5byte[i].ToString("x2"));
                //}
                //txtHashKey.Text = result.ToString();

                string outBuf = string.Empty;
                if (cc.Encryption(bufferKey, txtHashKey.Text, out outBuf) == 0) // キーの暗号化
                {
                    txtRdbKey.Text = outBuf;
                    if (check_encrypt_data(KEY, txtRdbKey.Text) == false)
                    {
                        MessageBox.Show("暗号化データがおかしい？");
                    }
                }
                else
                {   // Error
                    txtRdbKey.Text = "暗号化に失敗しました";
                }
            }
            #endregion  // MD5
        }

        //private void btnInputData_Click(object sender, RoutedEventArgs e)
        //{
        //    btnEncrypt.Visibility = System.Windows.Visibility.Visible;
        //    btnDecrypt.Visibility = System.Windows.Visibility.Hidden;
        //
        //    string srcFilePath = string.Empty;
        //    if (loadFileNameGet(ref srcFilePath) == true)
        //    {
        //        txtInputData.Text = srcFilePath;
        //        string folderName = ClassFileAccess.Instance.dirNameGet(srcFilePath);
        //        txtOutputData.Text = folderName + @"\enc_" + ClassFileAccess.Instance.fileNameGet(srcFilePath);
        //    }
        //    else
        //    {
        //        txtInputData.Text = string.Empty;
        //    }
        //}

        //private bool loadFileNameGet(ref string filePath)
        //{
        //    bool retsts = false;
        //    string fname = String.Empty;
        //    string inifname = String.Empty;                     // 初期ファイル名
        //    string filter = String.Empty;                       // フィルタ
        //    Int16 sel = 1;                                      // 選択フィルタ
        //    string title = String.Empty;
        //
        //    title = "Source File Select";
        //    inifname = "input.jpg";
        //    filter = "Data File(*.jpg)|*.jpg";
        //
        //    // 初期表示フォルダ記憶対応    2015.2.26 ishi11
        //    string _iniDirPath = Properties.Settings.Default.SAVE_DIALOG_PATH;
        //    fname = ClassFileAccess.Instance.openFileNameGet(_iniDirPath, inifname, filter, sel, title);
        //    filePath = fname;
        //    if (fname != string.Empty)
        //    {
        //        string folderName = ClassFileAccess.Instance.dirNameGet(fname);
        //        saveInitialFolder(folderName);
        //        retsts = true;
        //    }
        //    return retsts;
        //}

        //private void btnOutputData_Click(object sender, RoutedEventArgs e)
        //{
        //    btnEncrypt.Visibility = System.Windows.Visibility.Hidden;
        //    btnDecrypt.Visibility = System.Windows.Visibility.Visible;
        //
        //    string dstFilePath = string.Empty;
        //    if (loadFileNameGet(ref dstFilePath) == true)
        //    {
        //        txtOutputData.Text = dstFilePath;
        //        string folderName = ClassFileAccess.Instance.dirNameGet(dstFilePath);
        //        txtInputData.Text = folderName + @"\org_" + ClassFileAccess.Instance.fileNameGet(dstFilePath);
        //    }
        //    else
        //    {
        //        txtOutputData.Text = string.Empty;
        //    }
        //
        //}

        //private bool saveDirectoryNameGet(ref string filePath)
        //{
        //    bool retsts = false;
        //    string folderName = String.Empty;
        //
        //    // 初期表示フォルダ記憶対応    2015.2.26 ishi11
        //    string _iniDirPath = Properties.Settings.Default.SAVE_DIALOG_PATH;
        //    folderName = ClassFileAccess.Instance.openDirectoryNameGet(_iniDirPath);
        //    if (folderName != string.Empty)
        //    {
        //        saveInitialFolder(folderName);
        //        filePath = folderName;
        //        retsts = true;
        //    }
        //    return retsts;
        //}

        //private void saveInitialFolder(string folderName)
        //{
        //    Properties.Settings.Default.SAVE_DIALOG_PATH = folderName;
        //    Properties.Settings.Default.Save();
        //}

        private void btnEncrypt_Click(object sender, RoutedEventArgs e)
        {
            string key = txtHashKey.Text;
            //if ((key.Length != ClassCrypt.KEY_BYTE_SIZE) && (key.Length != ClassCrypt.KEYSHA256_BYTE_SIZE))
            if (key.Length != ClassCrypt.KEY_BYTE_SIZE)
            {   // 暗号化キーが 32bytesでない
                // Enckey NG
                MessageBox.Show("キーが正しくありません");
                return;
            }
            // Md5
            byte[] bufferKey = Encoding.UTF8.GetBytes(key);
            // Md5

            if (btnDataEnc.IsChecked == true)
            {
                string src = txtInputData.Text;
                if (src == string.Empty)
                {
                    string msg = "元データがありません";
                    txtRdbKey.Text = msg;
                    MessageBox.Show(msg);
                    return;
                }
                string dst = string.Empty;

                tbkStatus.Text = string.Empty;
                var sw2 = new System.Diagnostics.Stopwatch();            // 時間計測用
                sw2.Start();                                             // 時間計測用
                if (cc.Encryption(bufferKey, src, out dst) == 0)
                {
                    sw2.Stop();
                    txtOutputData.Text = dst;
                    TimeSpan ts = sw2.Elapsed;
                    double timeMs = ts.Milliseconds;
                    string msg = "暗号化に成功しました >>> " + timeMs.ToString() + "[ms]";
                    tbkStatus.Text = msg;
                    //string msg = "暗号化に成功しました" + Environment.NewLine + timeMs.ToString() + "[ms]";
                    //MessageBox.Show(msg);
                }
                else
                {
                    sw2.Stop();
                    txtOutputData.Text = string.Empty;
                    tbkStatus.Text = "暗号化に失敗しました";
                    //txtRdbKey.Text = "暗号化に失敗しました";
                }
            }
            else
            {
                string srcPath = txtInputData.Text;
                string dstPath = txtOutputData.Text;
                if ((srcPath == string.Empty) || (dstPath == string.Empty))
                {
                    MessageBox.Show("ファイル名がありません");
                    return;
                }
                // ファイルの上書きチェック
                if (ClassFileAccess.Instance.fileExist(dstPath) == true)
                {
                    MessageBox.Show("ファイルが存在します");
                    return;
                }

                tbkStatus.Text = string.Empty;
                var sw = new System.Diagnostics.Stopwatch();            // 時間計測用
                sw.Start();                                             // 時間計測用
                if (cc.EncryptionFile(key, srcPath, dstPath) == 0)
                {
                    sw.Stop();
                    TimeSpan ts = sw.Elapsed;
                    long timeMs = ts.Milliseconds;
                    string msg = "ファイル暗号化に成功しました >>> " + timeMs.ToString() + "[ms]";
                    tbkStatus.Text = msg;
                    //string msg = "ファイル暗号化に成功しました" + Environment.NewLine + timeMs.ToString() + "[ms]";
                    //MessageBox.Show(msg);
                }
                else
                {
                    sw.Stop();
                    txtRdbKey.Text = "ファイル暗号化に失敗しました";
                }
            }

        }

        private bool check_encrypt_data(string key, string data)
        {
            bool retsts = false;
            string buff = string.Empty;

            // test固定データ
            //data = "WDE/Q6zcoo6R7J8z3fmdjKd11aGDfSRUVUs535a06PzTT/1uO16Hu+V3IM/3VgW7xPbHoCDaSu6ei20xZgrQHQ=="; // PKCS5Padding by Java
            //data = "I75XWioWhRDtlgExMlRIt+TXQhDSVACpC6S+kmEfSbI5ZEOfz/W4IKm2WYMZm4Ar";                       // Nopadding by Java
            // 

            int ret = cc.Decryption(key, data, out buff);
            if (ret == 0)
            {
                retsts = true;
            }
            return retsts;
        }

        private void btnDecrypt_Click(object sender, RoutedEventArgs e)
        {
            imgFace.Source = null;

            string key = txtHashKey.Text;
            //if ((key.Length != ClassCrypt.KEY_BYTE_SIZE) && (key.Length != ClassCrypt.KEYSHA256_BYTE_SIZE))
            if (key.Length != ClassCrypt.KEY_BYTE_SIZE)
            {   // 暗号化キーが 32bytesでない
                // Enckey NG
                MessageBox.Show("キーが正しくありません");
                return;
            }

            if (btnDataEnc.IsChecked == true)
            {
                string src = txtOutputData.Text;
                if (src == string.Empty)
                {
                    string msg = "暗号化データがありません";
                    MessageBox.Show(msg);
                    return;
                }
                string dst = string.Empty;

                tbkStatus.Text = string.Empty;
                var sw2 = new System.Diagnostics.Stopwatch();            // 時間計測用
                sw2.Start();                                             // 時間計測用
                if (cc.Decryption(key, src, out dst) == 0)
                {
                    sw2.Stop();
                    txtInputData.Text = dst;
                    TimeSpan ts = sw2.Elapsed;
                    double timeMs = ts.Milliseconds;
                    string msg = "復号化に成功しました >>> " + timeMs.ToString() + "[ms]";
                    tbkStatus.Text = msg;
                    //string msg = "復号化に成功しました" + Environment.NewLine + timeMs.ToString() + "[ms]";
                    //MessageBox.Show(msg);
                }
                else
                {
                    sw2.Stop();
                    txtInputData.Text = string.Empty;
                    tbkStatus.Text = "復号化に失敗しました";
                    //MessageBox.Show("復号化に失敗しました");
                }
                
                byte[] decByte = Convert.FromBase64String(txtOutputData.Text);
                
            }
            else
            {
                string srcPath = txtOutputData.Text;
                string dstPath = txtInputData.Text;

                if ((srcPath == string.Empty) || (dstPath == string.Empty))
                {
                    MessageBox.Show("ファイルがありません");
                }
                // ファイルの上書きチェック
                if (ClassFileAccess.Instance.fileExist(dstPath) == true)
                {
                    MessageBoxResult result = System.Windows.MessageBox.Show(
                                                        "ファイルが存在します。上書きしますか？", 
                                                        "Warning", 
                                                        MessageBoxButton.YesNo, 
                                                        MessageBoxImage.Warning);
                    if (result == MessageBoxResult.No)
                    {
                        return;
                    }
                }

                tbkStatus.Text = string.Empty;
                var sw = new System.Diagnostics.Stopwatch();            // 時間計測用
                sw.Start();                                             // 時間計測用
                if (cc.DecryptionFile(key, srcPath, dstPath) == 0)
                {
                    sw.Stop();
                    ImageView();
                    TimeSpan ts = sw.Elapsed;
                    long timeMs = ts.Milliseconds;
                    string msg = "ファイル復号化に成功しました >>> " + timeMs.ToString() + "[ms]";
                    tbkStatus.Text = msg;
                    //string msg = "ファイル復号化に成功しました" + Environment.NewLine + timeMs.ToString() + "[ms]";
                    //MessageBox.Show(msg);
                }
                else
                {
                    tbkStatus.Text = "ファイル復号化に失敗しました";
                    //MessageBox.Show("ファイル復号化に失敗しました");
                }
            }
        }

        private void ImageView()
        {
#if true
            if (File.Exists(txtInputData.Text))
            {
                MemoryStream data = new MemoryStream(File.ReadAllBytes(txtInputData.Text)); 
                WriteableBitmap wbmp = new WriteableBitmap(BitmapFrame.Create(data));
                data.Close();
                imgFace.Source = wbmp;
            }
            else
            {
                imgFace.Source = new System.Windows.Media.Imaging.BitmapImage();
            }
#else
            BitmapImage bImage = new BitmapImage();
            try
            {
                bImage.BeginInit();
                bImage.UriSource = new Uri(txtInputData.Text);
                bImage.EndInit();
                imgFace.Source = bImage;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
#endif
        }
        #endregion

        private void initView()
        {
            DataView();
        }

        private void DataView()
        {
            //btnInputData.Visibility = System.Windows.Visibility.Hidden;
            //btnOutputData.Visibility = System.Windows.Visibility.Hidden;
            btnEncrypt.Visibility = System.Windows.Visibility.Visible;
            btnDecrypt.Visibility = System.Windows.Visibility.Visible;
            //txtInputData.Text = "データを入力してください";
            //txtOutputData.Text = "データを入力してください";
            lblInputData.Content = "データ";
            lblOutputData.Content = "暗号化データ";
        }

        private void FileView()
        {
            //btnInputData.Visibility = System.Windows.Visibility.Visible;
            //btnOutputData.Visibility = System.Windows.Visibility.Visible;
            btnEncrypt.Visibility = System.Windows.Visibility.Visible;
            btnDecrypt.Visibility = System.Windows.Visibility.Visible;
            //txtInputData.Text = "ファイル名を入力してください";
            //txtOutputData.Text = "ファイル名を入力してください";
            lblInputData.Content = "ファイル名";
            lblOutputData.Content = "暗号化ファイル名";
        }

        private void btnFileEnc_Checked(object sender, RoutedEventArgs e)
        {
            if (initWindow == true)
            {
                FileView();
            }
        }

        private void btnDataEnc_Checked(object sender, RoutedEventArgs e)
        {
            if (initWindow == true)
            {
                DataView();
            }
        }

        private void btnKeyClear_Click(object sender, RoutedEventArgs e)
        {
            txtHashKey.Text = string.Empty;
            txtRdbKey.Text = string.Empty;
        }

        private void txtOutputData_PreviewDragOver(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(System.Windows.DataFormats.FileDrop, true))
            {
                e.Effects = System.Windows.DragDropEffects.Copy;
            }
            else
            {
                e.Effects = System.Windows.DragDropEffects.None;
            }
            e.Handled = true;
        }

        private void txtOutputData_PreviewDrop(object sender, DragEventArgs e)
        {
            var dropFiles = e.Data.GetData(System.Windows.DataFormats.FileDrop) as string[];
            if (dropFiles == null) return;
            btnEncrypt.Visibility = System.Windows.Visibility.Visible;
            btnDecrypt.Visibility = System.Windows.Visibility.Hidden;
            txtOutputData.Text = dropFiles[0];
            string folderName = ClassFileAccess.Instance.dirNameGet(txtOutputData.Text);
            txtInputData.Text = folderName + @"\org_" + ClassFileAccess.Instance.fileNameGet(txtOutputData.Text);
            btnEncrypt.Visibility = System.Windows.Visibility.Hidden;
            btnDecrypt.Visibility = System.Windows.Visibility.Visible;
            btnFileEnc.IsChecked = true;
        }

        private void txtInputData_PreviewDragOver(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(System.Windows.DataFormats.FileDrop, true))
            {
                e.Effects = System.Windows.DragDropEffects.Copy;
            }
            else
            {
                e.Effects = System.Windows.DragDropEffects.None;
            }
            e.Handled = true;
        }

        private void txtInputData_PreviewDrop(object sender, DragEventArgs e)
        {
            var dropFiles = e.Data.GetData(System.Windows.DataFormats.FileDrop) as string[];
            if (dropFiles == null) return;
            txtInputData.Text = dropFiles[0];
            string folderName = ClassFileAccess.Instance.dirNameGet(txtInputData.Text);
            txtOutputData.Text = folderName + @"\enc_" + ClassFileAccess.Instance.fileNameGet(txtInputData.Text);
            btnEncrypt.Visibility = System.Windows.Visibility.Visible;
            btnDecrypt.Visibility = System.Windows.Visibility.Hidden;
            btnFileEnc.IsChecked = true;
        }

        private void btnKeyCheck_Click(object sender, RoutedEventArgs e)
        {
            string key = KEY;

            if (key.Length != ClassCrypt.KEY_BYTE_SIZE)
            {   // 暗号化キーが 32bytesでない
                // Enckey NG
                MessageBox.Show("キーが正しくありません");
                return;
            }

            string src = txtRdbKey.Text;
            if (src == string.Empty)
            {
                string msg = "暗号化データがありません";
                MessageBox.Show(msg);
                return;
            }
            string dst = string.Empty;

            if (cc.Decryption(key, src, out dst) == 0)
            {
                MessageBox.Show(dst);
            }
            else
            {
                MessageBox.Show("復号化に失敗しました");
            }

            byte[] decByte = Convert.FromBase64String(txtOutputData.Text);


        }

        private void btnDataClear_Click(object sender, RoutedEventArgs e)
        {
            tbkStatus.Text = "---";
            txtInputData.Text = "";
            txtOutputData.Text = "";
            btnEncrypt.Visibility = System.Windows.Visibility.Visible;
            btnDecrypt.Visibility = System.Windows.Visibility.Visible;
            imgFace.Source = null;
        }


    }
}
