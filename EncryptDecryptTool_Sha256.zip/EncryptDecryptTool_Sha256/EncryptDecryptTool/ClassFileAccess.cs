﻿using System;
using System.Collections.Generic;
//using System.Linq;
//using System.Text;
using System.IO;                    // IO 
using System.Data;                  // DataTable
using System.Windows;               //
using System.Windows.Forms;         //


namespace EncryptDecryptTool
{
    class ClassFileAccess
    {
        private static ClassFileAccess instance;

        public static ClassFileAccess Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new ClassFileAccess();
                }
                return instance;
            }
        }

        #region Directory Utility
        // ディレクトリ有無のチェック
        public bool dirCheck(string dirPath)
        {
            bool retsts = false;

            DirectoryInfo dirInfo = new DirectoryInfo(dirPath);

            // ディレクトリがあるかのチェック
            if (dirInfo.Exists == true)
            {
                retsts = true;
            }
            return retsts;
        }

        // ディレクトリ名の獲得
        public string dirNameGet(String passName)
        {
            String dirName;

            dirName = Path.GetDirectoryName(passName);
            return dirName;
        }

        // ダイアログで選択したフォルダ名を獲得する
        public string openDirectoryNameGet(string defaultPath)
        {
            string passName = String.Empty;

            //FolderBrowserDialogクラスのインスタンスを作成
            FolderBrowserDialog fbd = new FolderBrowserDialog();

            //上部に表示する説明テキストを指定する
            fbd.Description = "Please select folder ...";
            //ルートフォルダを指定する
            //デフォルトでDesktop
            fbd.RootFolder = Environment.SpecialFolder.Desktop;
            //最初に選択するフォルダを指定する
            //RootFolder以下にあるフォルダである必要がある
            //fbd.SelectedPath = @"C:\ASF900";
            fbd.SelectedPath = defaultPath;
            //ユーザーが新しいフォルダを作成できるようにする
            //デフォルトでTrue
            fbd.ShowNewFolderButton = true;

            //ダイアログを表示する
            if (fbd.ShowDialog() == DialogResult.OK)
            {
                //選択されたフォルダを表示する
                Console.WriteLine(fbd.SelectedPath);
                passName = fbd.SelectedPath;
            }
            return passName;
        }

        #endregion

        // カレントパスの獲得
        public string currentDirectoryGet()
        {
            string curPass = System.IO.Directory.GetCurrentDirectory();
            return curPass;
        }

        // 1個上のパスを獲得
        public string parentDirectoryGet(string path)
        {
            string upPath = System.IO.Directory.GetParent(path).ToString();

            return upPath;
        }

        public string parentDirectoryGet()
        {
            string curPass = System.IO.Directory.GetCurrentDirectory();
            return parentDirectoryGet(curPass);
        }

        // ディレクトリ名のみを獲得
        public string childDirectoryGet(string path)
        {
            string searChar = "_face";
            string dwPath = "01_face";
            int len = path.Length;
            int pos = path.LastIndexOf(searChar);
            if (pos >= 2)
            {
                pos -= 2;
                dwPath = path.Substring(pos, len - pos);
            }
            return dwPath;
        }

        // カレントパスの設定
        public bool currentDirectorySet(string dirName)
        {
            bool retsts = false;

            try
            {
                System.IO.Directory.SetCurrentDirectory(dirName);
                retsts = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return retsts;
        }

        #region File Utility
        // ファイル名の獲得
        public String fileNameGet(String passName)
        {
            String fileName;

            fileName = Path.GetFileName(passName);
            return fileName;
        }

        // 拡張子なしのファイル名の獲得
        public String fileNameGetWithoutExtension(String passName)
        {
            String fileName;

            fileName = Path.GetFileNameWithoutExtension(passName);
            return fileName;
        }

        public string extensionNameGet(string passName)
        {
            return Path.GetExtension(passName);
        }

        // ファイルチェック
        public bool fileExist(String filepath)
        {
            bool retsts = false;
            if (File.Exists(filepath) == true)
            {
                retsts = true;
            }
            return retsts;
        }

        // ファイルオープン
        public bool fileOpen(String filename)
        {
            bool retsts = false;

            // ファイルがないと処理がとまってしまうのでチェックを入れる。
            if (System.IO.File.Exists(filename) == false)
            {   // ファイルがなかったらファイルをオープンする

            }

            return retsts;
        }

        // ファイルの読出し
        public bool fileRead(string filepath, ref string buf)
        {
            bool retsts = false;

            if (System.IO.File.Exists(filepath))
            {
                StreamReader sr = null;
                try
                {
                    sr = new StreamReader(filepath, System.Text.Encoding.UTF8);
                    buf = sr.ReadToEnd();
                    retsts = true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    sr.Close();
                }
            }
            return retsts;
        }

        // ファイル書込み
        public bool fileWrite(string filepath, string buf)
        {
            bool retsts = false;

            if (System.IO.File.Exists(filepath))
            {
                fileDelete(filepath);
            }

            StreamWriter sw = null;
            try
            {
                sw = new StreamWriter(filepath, false, System.Text.Encoding.UTF8);
                sw.Write(buf);
                retsts = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                sw.Close();
            }

            return retsts;
        }

        // ファイルの消去
        public bool fileDelete(string filePath)
        {
            bool retsts = false;

            try
            {
                File.Delete(filePath);
                retsts = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return retsts;
        }

        // ファイルサイズのチェック LOG書込み禁止
        public bool fileSizeGet(string filePath, ref long fileSize)
        {
            bool retsts = false;

            try
            {
                FileInfo fi = new FileInfo(filePath);
                fileSize = fi.Length;
                retsts = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return retsts;
        }

        // ファイルのリネーム    LOG書込み禁止
        public bool fileRename(string srcPath, string destPath)
        {
            bool retsts = false;

            try
            {
                File.Move(srcPath, destPath);
                retsts = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return retsts;
        }

        // ダイアログで選択したファイル名を獲得する
        public string openFileNameGet(string ininame, string filter, Int16 filterSelect, string title)
        {
            string inidir = @"./";
            return openFileNameGet(inidir, ininame, filter, filterSelect, title);
        }
        public string openFileNameGet(string inidir, string ininame, string filter, Int16 filterSelect, string title)
        {
            string passName = String.Empty;

            OpenFileDialog ofd = new OpenFileDialog();      // OpenFileDialog インスタンス作成
            ofd.FileName = ininame;                         // はじめに表示されるファイル名設定
            if (inidir != String.Empty)
            {
                ofd.InitialDirectory = inidir;              // はじめに表示されるディレクトリ名設定
            }

            ofd.Filter = filter;                            // ファイルのフィルタ
            ofd.FilterIndex = filterSelect;                 // 初期フィルタ選択

            ofd.Title = title;                              // タイトル
            //ofd.RestoreDirectory = true;
            ofd.RestoreDirectory = false;                   // ディレクトリは元には戻さない
            ofd.CheckFileExists = true;
            ofd.CheckPathExists = true;

            //ダイアログを表示する
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                passName = ofd.FileName;
            }

            return passName;
        }

        public string openFileNameGet(string ininame, string filter, Int16 filterSelect)
        {
            return openFileNameGet(ininame, filter, filterSelect, "Please select file ...");
        }




        #endregion

        #region For Alarm History
        public String fileNameConvert(Int64 camNo, String passName)
        {
            String fileName;
            String camName;

            fileName = Path.GetFileName(passName);
            camName = String.Format("{0:D3}", camNo);
            fileName = camName + "_" + Path.GetFileName(passName);

            return fileName;
        }

        public void fileCopy(Int64 camNo, String passName, String dstDirName)
        {
            FileInfo fi;
            String newfileName;
            String dstfileName;

            // ファイルがないと処理がとまってしまうのでチェックを入れる。
            if (System.IO.File.Exists(passName) == false)
            {   // ファイルがなかったらコピー処理をやめる
                return;
            }

            // FileInfoオブジェクトの生成
            fi = new System.IO.FileInfo(passName);

            // ファイル名変換
            newfileName = fileNameConvert(camNo, passName);     // カメラ番号を付与したファイル名を作成
            dstfileName = dstDirName + "/" + newfileName;       // 格納先ファイル名の作成

            try
            {
                // ファイルコピー
                FileInfo copyFile = fi.CopyTo(dstfileName);         // ファイルのコピー
            }
            catch (Exception ex)
            {
                //メッセージボックスを表示する
                System.Windows.Forms.MessageBox.Show(ex.Message, "file copy failed[" + dstfileName + "]", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        #endregion

    }
}
