﻿using System;
using System.IO;                        //
//using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace EncryptDecryptTool
{
    class ClassCrypt
    {
        private string encKey = string.Empty;
        public const int BLOCK_SIZE = 128;
        //public const int BLOCKSHA256_SIZE = 256;
        public const int KEY_SIZE = 256;
        //public const int KEYSHA256_SIZE = 512;
        public const int KEY_BYTE_SIZE = 32;
        //public const int KEYSHA256_BYTE_SIZE = 64;
        public const int CRYPT_OK = 0;
        public const int CRYPT_ERROR_KEYSIZE = 1;

        //private static ClassFileAccess instance;
        //
        //public string EncKey
        //{
        //    get { return this.encKey; }
        //    set { this.encKey = value; }
        //}

        public int Encryption(byte[] key, string inBuff, out string outBuf)
        {
            int retsts = 1;
            int blockSize = BLOCK_SIZE;
            int keySize = KEY_SIZE;
            outBuf = string.Empty;

            // Keyサイズチェック
            if (key.Length == KEY_BYTE_SIZE)
            {
                blockSize = BLOCK_SIZE;
                keySize = KEY_SIZE;             // 256
            }
            //else if (key.Length == KEYSHA256_BYTE_SIZE)
            //{
            //    blockSize = BLOCKSHA256_SIZE;
            //    keySize = KEYSHA256_SIZE;       // 512
            //}
            else
            {
                return retsts;
            }

            try
            {
                // AES器の作成と初期設定
                var am = new AesManaged();
                am.BlockSize = blockSize;
                am.KeySize = keySize;
                //am.BlockSize = BLOCK_SIZE;
                //am.KeySize = KEY_SIZE;
                am.Mode = CipherMode.CBC;
                am.Padding = PaddingMode.PKCS7;
                //am.Padding = PaddingMode.Zeros;
                //am.Padding = PaddingMode.None;
                am.Key = key;                                       // 暗号化キー設定
                am.GenerateIV();                                   // IVの自動生成
                ICryptoTransform encryptor = am.CreateEncryptor(am.Key, am.IV);
                MemoryStream outStream = new MemoryStream();              // Write Buffer準備
                using (CryptoStream cs = new CryptoStream(outStream, encryptor, CryptoStreamMode.Write))
                {
                    byte[] inBuffer = Encoding.UTF8.GetBytes(inBuff);   // 文字列->バイト列変換
                    outStream.Write(am.IV, 0, 16);
                    cs.Write(inBuffer, 0, inBuffer.Length);
                }

                byte[] result = outStream.ToArray();
                outBuf = Convert.ToBase64String(result);
                retsts = 0;
                outStream.Close();
                encryptor.Dispose();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return retsts;
        }

#if false
        public int Encryption(string key, string inBuff, out string outBuf)
        {
            int retsts = 1;
            int blockSize = BLOCK_SIZE;
            int keySize=KEY_SIZE;
            outBuf = string.Empty;

            // Keyサイズチェック
            if (key.Length == KEY_BYTE_SIZE)
            {
                blockSize = BLOCK_SIZE;
                keySize = KEY_SIZE;             // 256
            }
            //else if (key.Length == KEYSHA256_BYTE_SIZE)
            //{
            //    blockSize = BLOCKSHA256_SIZE;
            //    keySize = KEYSHA256_SIZE;       // 512
            //}
            else
            {
                return retsts;
            }

            try
            {
                // AES器の作成と初期設定
                var am = new AesManaged();
                am.BlockSize = blockSize;
                am.KeySize = keySize;
                //am.BlockSize = BLOCK_SIZE;
                //am.KeySize = KEY_SIZE;
                am.Mode = CipherMode.CBC;
                am.Padding = PaddingMode.PKCS7;
                //am.Padding = PaddingMode.Zeros;
                //am.Padding = PaddingMode.None;
                byte[] bufferKey = Encoding.UTF8.GetBytes(key);    // 暗号化キー用 文字列->バイト列変換
                am.Key = bufferKey;                                // 暗号化キー設定
                am.GenerateIV();                                   // IVの自動生成
                ICryptoTransform encryptor = am.CreateEncryptor(am.Key, am.IV);
                MemoryStream outStream = new MemoryStream();              // Write Buffer準備
                using (CryptoStream cs = new CryptoStream(outStream, encryptor, CryptoStreamMode.Write))
                {
                    byte[] inBuffer = Encoding.UTF8.GetBytes(inBuff);   // 文字列->バイト列変換
                    outStream.Write(am.IV, 0, 16);
                    cs.Write(inBuffer, 0, inBuffer.Length);
                }

                byte[] result = outStream.ToArray();
                outBuf = Convert.ToBase64String(result);
                retsts = 0;
                outStream.Close();
                encryptor.Dispose();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return retsts;
        }
#endif

        public int EncryptionSha256(byte[] key, string inBuf, out string outBuf)
        {
            int retsts = 1;
            int blockSize = BLOCK_SIZE;
            int keySize = KEY_SIZE;
            outBuf = string.Empty;

            // Keyサイズチェック
            if (key.Length == KEY_BYTE_SIZE)
            {
                blockSize = BLOCK_SIZE;
                keySize = KEY_SIZE;             // 256
            }
            //else if (key.Length == KEYSHA256_BYTE_SIZE)
            //{
            //    blockSize = BLOCKSHA256_SIZE;
            //    keySize = KEYSHA256_SIZE;       // 512
            //}
            else
            {
                return retsts;
            }

            try
            {
                // AES器の作成と初期設定
                var am = new AesManaged();
                am.BlockSize = blockSize;
                am.KeySize = keySize;
                //am.BlockSize = BLOCK_SIZE;
                //am.KeySize = KEY_SIZE;
                am.Mode = CipherMode.CBC;
                am.Padding = PaddingMode.PKCS7;
                //am.Padding = PaddingMode.Zeros;
                //am.Padding = PaddingMode.None;
                byte[] bufferKey = key;                            // 暗号化キー用 文字列->バイト列変換
                am.Key = bufferKey;                                // 暗号化キー設定
                am.GenerateIV();                                   // IVの自動生成
                ICryptoTransform encryptor = am.CreateEncryptor(am.Key, am.IV);
                MemoryStream outStream = new MemoryStream();              // Write Buffer準備
                using (CryptoStream cs = new CryptoStream(outStream, encryptor, CryptoStreamMode.Write))
                {
                    byte[] inBuffer = Encoding.UTF8.GetBytes(inBuf);   // 文字列->バイト列変換
                    outStream.Write(am.IV, 0, 16);
                    cs.Write(inBuffer, 0, inBuffer.Length);
                }

                byte[] result = outStream.ToArray();
                outBuf = Convert.ToBase64String(result);
                retsts = 0;
                outStream.Close();
                encryptor.Dispose();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return retsts;
        }


        public int EncryptionFile(string key, string srcFilePath, string dstFilePath)
        {
            int retsts = 1;
            int blockSize = BLOCK_SIZE;
            int keySize = KEY_SIZE;

            // Keyサイズチェック
            if (key.Length == KEY_BYTE_SIZE)
            {
                blockSize = BLOCK_SIZE;
                keySize = KEY_SIZE;             // 256
            }
            //else if (key.Length == KEYSHA256_BYTE_SIZE)
            //{
            //    blockSize = BLOCKSHA256_SIZE;
            //    keySize = KEYSHA256_SIZE;       // 512
            //}
            else
            {
                return retsts;
            }

            // 入力の準備
            FileStream inStream = new FileStream(srcFilePath, FileMode.Open, FileAccess.Read);
            // 出力準備
            FileStream outStream = new FileStream(dstFilePath, FileMode.Create, FileAccess.Write);

            // AES器の作成と初期設定
            var am = new AesManaged();
            am.BlockSize = blockSize;
            am.KeySize = keySize;
            //am.BlockSize = BLOCK_SIZE;
            //am.KeySize = KEY_SIZE;
            am.Mode = CipherMode.CBC;
            am.Padding = PaddingMode.PKCS7;
            byte[] bKey = Encoding.UTF8.GetBytes(key);                      // 暗号化キー用 文字列->バイト列変換
            am.Key = bKey;                                                  // 暗号化キー設定
            am.GenerateIV();                                                // IVの自動生成
            ICryptoTransform encryptor = am.CreateEncryptor(am.Key, am.IV);
            outStream.Write(am.IV, 0, 16);                                  // IVの書込み

            using (CryptoStream cs = new CryptoStream(outStream, encryptor, CryptoStreamMode.Write))
            {
                byte[] buffer = new byte[4096];
                int len;
                while (true)
                {
                    len = inStream.Read(buffer, 0, buffer.Length);
                    if (len == 0)
                    {
                        break;
                    }
                    cs.Write(buffer, 0, len);
                }
                retsts = 0;
            }
            inStream.Close();
            outStream.Close();
            encryptor.Dispose();               

            return retsts;
        }

#if false
        private static void GenerateKeyFromPassword(string password, int keySize, out byte[] key, int blockSize, out byte[] iv)
        {
            //パスワードから共有キーと初期化ベクタを作成する
            //saltを決める
            byte[] salt = System.Text.Encoding.UTF8.GetBytes("saltは必ず8バイト以上");
            //Rfc2898DeriveBytesオブジェクトを作成する
            System.Security.Cryptography.Rfc2898DeriveBytes deriveBytes =
                new System.Security.Cryptography.Rfc2898DeriveBytes(password, salt);
            //.NET Framework 1.1以下の時は、PasswordDeriveBytesを使用する
            //System.Security.Cryptography.PasswordDeriveBytes deriveBytes =
            //    new System.Security.Cryptography.PasswordDeriveBytes(password, salt);
            //反復処理回数を指定する デフォルトで1000回
            deriveBytes.IterationCount = 1000;

            //共有キーと初期化ベクタを生成する
            key = deriveBytes.GetBytes(keySize / 8);
            iv = deriveBytes.GetBytes(blockSize / 8);
        }
#endif

        public int Decryption(string key, string inBuff, out string outBuf)
        {
            int retsts = 1;
            int blockSize = BLOCK_SIZE;
            int keySize = KEY_SIZE;
            outBuf = string.Empty;

            // Keyサイズチェック
            if (key.Length == KEY_BYTE_SIZE)
            {
                blockSize = BLOCK_SIZE;
                keySize = KEY_SIZE;             // 256
            }
            //else if (key.Length == KEYSHA256_BYTE_SIZE)
            //{
            //    blockSize = BLOCKSHA256_SIZE;
            //    keySize = KEYSHA256_SIZE;       // 512
            //}
            else
            {
                return retsts;
            }

            try
            {
                byte[] src = Convert.FromBase64String(inBuff);          // 暗号化データのバイト列
                var inStream = new MemoryStream(src, false);            // 暗号化データのストリーム(Read)
                var outStream = new MemoryStream();                     // 復号化データのストリーム(Write)
                var am = new AesManaged();
                am.BlockSize = blockSize;
                am.KeySize = keySize;
                //am.BlockSize = BLOCK_SIZE;
                //am.KeySize = KEY_SIZE;
                am.Mode = CipherMode.CBC;
                am.Padding = PaddingMode.PKCS7;
                //am.Padding = PaddingMode.Zeros;
                //am.Padding = PaddingMode.None;

                byte[] iv = new byte[16];
                int ivLength = inStream.Read(iv, 0, 16);                // inStreamのポインタは+16
                if (ivLength < 16)
                {
                    return retsts;
                }

                byte[] bKey = Encoding.UTF8.GetBytes(key);
                var decryptor = am.CreateDecryptor(bKey, iv);

                try
                {
                    using (CryptoStream cs = new CryptoStream(inStream, decryptor, CryptoStreamMode.Read))
                    {
                        byte[] buffer = new byte[4096];
                        int len;
                        while (true)
                        {
                            len = cs.Read(buffer, 0, 4096);
                            if (len == 0)
                            {
                                break;
                            }
                            outStream.Write(buffer, 0, len);
                        }
                        outBuf = System.Text.Encoding.UTF8.GetString(outStream.ToArray());
                    }
                    inStream.Close();
                    outStream.Close();
                    decryptor.Dispose();
                    retsts = 0;
                }
                catch (CryptographicException ex)
                {
                    inStream.Close();
                    outStream.Close();
                    decryptor.Dispose();
                    outBuf = ex.Message;
                }
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
            }
            return retsts;
        }

        public int DecryptionFile(string key, string srcFilePath, string dstFilePath)
        {
            int retsts = 1;
            int blockSize = BLOCK_SIZE;
            int keySize = KEY_SIZE;

            // Keyサイズチェック
            if (key.Length == KEY_BYTE_SIZE)
            {
                blockSize = BLOCK_SIZE;
                keySize = KEY_SIZE;             // 256
            }
            //else if (key.Length == KEYSHA256_BYTE_SIZE)
            //{
            //    blockSize = BLOCKSHA256_SIZE;
            //    keySize = KEYSHA256_SIZE;       // 512
            //}
            else
            {
                return retsts;
            }

            try
            {
                // Keyの獲得
                byte[] bKey = Encoding.UTF8.GetBytes(key);

                // IVの獲得
                FileStream inStream = new FileStream(srcFilePath, FileMode.Open, FileAccess.Read);
                byte[] iv = new byte[16];
                int ivLength = inStream.Read(iv, 0, 16);                // inStreamのポインタは+16
                if (ivLength < 16)
                {
                    inStream.Close();
                    return retsts;
                }

                // 出力準備
                FileStream outStream = new FileStream(dstFilePath, FileMode.Create, FileAccess.Write);

                // AES復号器の生成
                var am = new AesManaged();
                am.BlockSize = blockSize;
                am.KeySize = keySize;
                //am.BlockSize = BLOCK_SIZE;
                //am.KeySize = KEY_SIZE;
                am.Mode = CipherMode.CBC;
                am.Padding = PaddingMode.PKCS7;
                var decryptor = am.CreateDecryptor(bKey, iv);

                try
                {
                    using (CryptoStream cs = new CryptoStream(inStream, decryptor, CryptoStreamMode.Read))
                    {
                        byte[] buffer = new byte[4096];
                        int len;
                        while (true)
                        {
                            len = cs.Read(buffer, 0, 4096);
                            if (len == 0)
                            {
                                break;
                            }
                            outStream.Write(buffer, 0, len);
                        }
                    }
                    inStream.Close();
                    outStream.Close();
                    decryptor.Dispose();
                    retsts = 0;
                }
                catch (CryptographicException ex)
                {
                    inStream.Close();
                    outStream.Close();
                    decryptor.Dispose();
                    Console.WriteLine("Decode err: " + ex.Message);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return retsts;
        }
    }
}
